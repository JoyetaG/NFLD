# NFLD project: dietary factors and NAFLD in Korean adults (KNHANES 2008–2011)

Analysis code, tables and figures for a cross-sectional study of NAFLD (hepatic steatosis index > 36) in KNHANES 2008–2011.
The work is a leakage-controlled evaluation: it separates the contribution of diet from the variables that define the outcome.

## What is in this repository
- `code/`    Python analysis scripts (cohort construction, regression, nested cross-validation, SHAP, sensitivity analyses, figures)
- `tables/`  Result tables (CSV/JSON), including `hyperparameter_search_spaces.csv`
- `figures/` Figures 1–9 and Supplementary Figure S1
- `requirements.txt`  Python package versions used

## Data
**Participant-level data are not included.** KNHANES data are public but their redistribution is governed by the Korea Disease Control and
Prevention Agency (KDCA). Download the 2008–2011 files from https://knhanes.kdca.go.kr and place the merged file in `data/`.
The supplied merged file contained **12,604 duplicated records** (every 2010 and 2011 record appeared twice) and 18 malformed lines;
`code/build_cohort.py` removes them. `code/uti_dup_check.py` illustrates how duplicates can inflate cross-validated performance.

## Run order (see `code/` for details)
1. `build_cohort.py` – de-duplicate, apply exclusions, write cohort and flow counts
2. `analysis_descriptive.py` – weighted prevalence, Table 1, adjusted associations
3. `ml_nested.py` – nested CV (outer 10-fold grouped by PSU; inner 3-fold tuning; in-fold preprocessing), 8 classifiers × 5 feature sets (about 50 min on one CPU, resumable)
4. `nested_analysis.py`, `nested_plausible.py`, `nested_figures.py` – results, plausible-energy-reporter check, Figures 5–7
5. `analysis_nlrs.py` – Nutritional Liver Risk Score derivation and temporal validation
6. `extras_analysis.py`, `univariate_corr.py`, `partial_corr.py`, `robustness.py`, `data_audit.py`, `plausible_reporters.py`, `causal_extras.py` – additional analyses (Tables 5–12)
7. `figs_dashboards.py`, `fig_flow.py`, `fig_s1.py`, `dag_fig.py` – Figures 1–3, S1 and 9

The scripts use absolute paths from the environment in which they were run. `set_paths.sh` rewrites them to relative paths (untested end to end).

## Caveats
- NAFLD is defined by the HSI, a surrogate; no imaging or histology was available.
- Saturated fat, n-3, added sugar, folate, dietary vitamins D/E and hsCRP are not in the analysed file.
- Associations are cross-sectional and are not evidence of causation.
