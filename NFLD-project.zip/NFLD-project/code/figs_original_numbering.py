import pandas as pd, numpy as np, re, json, pickle, shutil, os
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
NAVY, TEAL, RED, GOLD = "#1B3A6B", "#0E7C7B", "#C0392B", "#C8963E"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
O = "/mnt/user-data/outputs/"
d = pd.read_pickle("/home/claude/out/analytic.pkl"); d["w"] = d.wt_tot/d.wt_tot.mean()
def ratio(y, w, h, c):
    y=np.asarray(y,float); w=np.asarray(w,float); p=(w*y).sum()/w.sum(); z=w*(y-p)/w.sum()
    cl=pd.DataFrame(dict(z=z,h=np.asarray(h),c=np.asarray(c))).groupby(["h","c"]).z.sum().reset_index(); v=0
    for _,g in cl.groupby("h"):
        n=len(g); v+= n/(n-1)*((g.z-g.z.mean())**2).sum() if n>1 else 0
    return p, np.sqrt(v)
d["ag"] = pd.cut(d.age, [19,29,39,49,59,69,120], labels=["20–29","30–39","40–49","50–59","60–69","70+"])
# Figure 2: prevalence by age and sex
fig, ax = plt.subplots(figsize=(7.2, 5)); labs=list(d.ag.cat.categories); x=np.arange(6); bw=.38
for k,(sx,nm,col) in enumerate([(1,"Men",NAVY),(2,"Women",TEAL)]):
    ps=[];es=[]
    for g in labs:
        m=(d.sex==sx)&(d.ag==g); p,s=ratio(d.nafld[m],d.w[m],d.kstrata[m],d.grp[m]); ps.append(p*100); es.append(1.96*s*100)
    ax.bar(x+(k-.5)*bw, ps, bw, yerr=es, color=col, capsize=2, label=nm)
    for xi,p,e in zip(x+(k-.5)*bw, ps, es): ax.text(xi, p+e+.6, f"{p:.0f}", ha="center", fontsize=8)
ax.set_xticks(x); ax.set_xticklabels(labs); ax.set_xlabel("Age group (years)"); ax.set_ylabel("Survey-weighted prevalence of HSI > 36 (%)"); ax.legend(frameon=False)
ax.set_title("NAFLD (HSI > 36) prevalence by age and sex\n(survey-weighted, 95% CI)", fontweight="bold", color=NAVY)
plt.tight_layout(); plt.savefig(O+"Figure2_Prevalence_by_Age_Sex.png", dpi=180); plt.close()
# Figure 3: adjusted associations (forest)
reg = pd.read_csv("/home/claude/out/table_regression.csv")
def parse(s): m=re.match(r"([\d.]+) \(([\d.]+)–([\d.]+)\)", s); return tuple(map(float,m.groups()))
order=["Dietary fibre","Sodium","Potassium","Vitamin C","Calcium","Total fat","Carbohydrate","Protein","Water","Energy"]
r=reg.set_index("Nutrient").loc[order]; ypos=np.arange(10)[::-1]
c3=[c for c in reg.columns if c.startswith("Model 3 (+ total")][0]; cb=[c for c in reg.columns if "+ BMI" in c and not c.endswith(" p")][0]
fig, ax = plt.subplots(figsize=(7.6, 5.8))
for yy,(nm,row) in zip(ypos, r.iterrows()):
    o,l,h=parse(row[c3]); ax.plot([l,h],[yy+.12]*2,color=TEAL,lw=2); ax.plot(o,yy+.12,"D",color=TEAL,ms=6)
    o2,l2,h2=parse(row[cb]); ax.plot([l2,h2],[yy-.12]*2,color=GOLD,lw=2); ax.plot(o2,yy-.12,"s",color=GOLD,ms=5)
ax.axvline(1,color="k",ls="--",lw=1); ax.set_yticks(ypos); ax.set_yticklabels([f"{n}\n({r.loc[n,'Increment']})" for n in order], fontsize=8.5)
ax.set_xlabel("Adjusted odds ratio (95% CI) for HSI-defined NAFLD"); ax.set_xlim(0.9,1.16)
ax.legend(handles=[Line2D([0],[0],color=TEAL,marker="D",label="Model 3 (age, sex, smoking, activity, education, income, energy)"),Line2D([0],[0],color=GOLD,marker="s",label="Model 3 + BMI (over-adjusted; BMI is part of HSI)")],frameon=False,fontsize=8,loc="upper center",bbox_to_anchor=(0.4,-0.13))
ax.set_title("Multivariable-adjusted associations of dietary intake\nwith NAFLD (survey-weighted)", fontweight="bold", color=NAVY)
plt.tight_layout(); plt.savefig(O+"Figure3_Adjusted_Associations.png", dpi=180); plt.close()
# renames to the ORIGINAL manuscript figure numbers
for old,new in [("Fig1_participant_flow.png","Figure1_Participant_Flow.png"),("Fig6_NLRS_validation.png","Figure4_NLRS_Validation.png"),("Fig3_ROC_feature_sets.png","Figure5_ML_Feature_Sets.png"),("Fig4_SHAP_HSI_free.png","Figure6_SHAP_Importance.png"),("Fig5_SHAP_dependence.png","Figure7_SHAP_Dependence.png")]:
    shutil.copy(O+old, O+new); os.remove(O+old)
os.remove(O+"Fig2_prevalence_and_associations.png")
# NLRS table (temporal derivation) + extras
R = pickle.load(open("/home/claude/out/nlrs.pkl","rb"))["temporal"]["tbl"].copy()
R = R.sort_values(["Weight_0_10"], ascending=False, kind="stable").reset_index(drop=True)
nl = [[i+1, r_.Nutrient, r_.Direction, f"{r_.LASSO_coef:+.3f}", int(r_.Weight_0_10)] for i,r_ in R.iterrows()]
j = json.load(open("/home/claude/out/ms_data.json")); j["nlrs"]=nl; json.dump(j, open("/home/claude/out/ms_data.json","w"))
print(sorted(os.listdir(O))); print(nl[:3])
