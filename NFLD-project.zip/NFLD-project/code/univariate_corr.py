import pandas as pd, numpy as np, json, warnings
warnings.filterwarnings("ignore")
from scipy import stats
dd = pd.read_pickle("/home/claude/out/extras_data.pkl").reset_index(drop=True)
dd["fastfood"] = dd.F_HAMBER + dd.F_PIZZA + dd.F_FRIED   # raw index for medians (sum of frequency categories)
cont = [("Dietary fibre (g/day)","N_FIBER"),("Sodium (mg/day)","N_NA"),("Potassium (mg/day)","N_K"),("Energy (kcal/day)","N_EN"),("Total fat (g/day)","N_FAT"),("Fat, % of energy","fat_pct"),
        ("Fast-food index (sum of hamburger + pizza + fried-food categories)","fastfood"),("Hamburger frequency (category)","F_HAMBER"),("Pizza frequency (category)","F_PIZZA"),("Fried-food frequency (category)","F_FRIED"),
        ("Soda frequency (category)","F_SODA"),("Serum 25-hydroxyvitamin D (ng/mL)","HE_vitD"),("Estimated 24-h urinary sodium (mEq/day)","urineNa_excretion")]
rows=[]
a, b = dd[dd.nafld==1], dd[dd.nafld==0]
def q(s): x=s.dropna().quantile([.25,.5,.75]); return f"{x[.5]:.1f} ({x[.25]:.1f}–{x[.75]:.1f})"
for lab,c in cont:
    x,y = a[c].dropna(), b[c].dropna(); u_,p = stats.mannwhitneyu(x,y); rbc = 2*u_/(len(x)*len(y))-1
    m1 = dd[[c,"HSI"]].dropna(); m2 = dd[[c,"HE_alt"]].dropna()
    r1,p1 = stats.spearmanr(m1[c], m1.HSI); r2,p2 = stats.spearmanr(m2[c], m2.HE_alt)
    rows.append(dict(var=lab, nafld=q(a[c]), non=q(b[c]), test="Mann–Whitney U", stat=f"r = {rbc:+.2f}", p=p, rho_hsi=r1, p_hsi=p1, rho_alt=r2, p_alt=p2))
# physical inactivity: chi-square 2x2
ct = pd.crosstab(dd.inactive, dd.nafld); chi2,p,_,_ = stats.chi2_contingency(ct); V = np.sqrt(chi2/ct.values.sum())
m1 = dd[["inactive","HSI"]].dropna(); m2 = dd[["inactive","HE_alt"]].dropna(); r1,p1 = stats.spearmanr(m1.inactive,m1.HSI); r2,p2 = stats.spearmanr(m2.inactive,m2.HE_alt)
rows.append(dict(var="Physical inactivity (%)", nafld=f"{dd.inactive[dd.nafld==1].mean()*100:.1f}%", non=f"{dd.inactive[dd.nafld==0].mean()*100:.1f}%", test="Chi-square", stat=f"V = {V:.3f}", p=p, rho_hsi=r1,p_hsi=p1,rho_alt=r2,p_alt=p2))
# fast-food highest tertile: chi-square
dd["ff_hi"] = (dd.fastfood.rank(method="first") > 2/3*len(dd)).astype(int)
ct = pd.crosstab(dd.ff_hi, dd.nafld); chi2,p,_,_ = stats.chi2_contingency(ct); V=np.sqrt(chi2/ct.values.sum())
rows.append(dict(var="Highest fast-food tertile (%)", nafld=f"{dd.ff_hi[dd.nafld==1].mean()*100:.1f}%", non=f"{dd.ff_hi[dd.nafld==0].mean()*100:.1f}%", test="Chi-square", stat=f"V = {V:.3f}", p=p, rho_hsi=np.nan,p_hsi=np.nan,rho_alt=np.nan,p_alt=np.nan))
T = pd.DataFrame(rows)
def bh(p):
    p=np.asarray(p,float); ok=~np.isnan(p); out=np.full_like(p,np.nan); pv=p[ok]; n=len(pv); o=np.argsort(pv); r=pv[o]*n/(np.arange(n)+1); r=np.minimum.accumulate(r[::-1])[::-1]; tmp=np.empty(n); tmp[o]=np.minimum(r,1); out[ok]=tmp; return out
T["q"]=bh(T.p); T["q_hsi"]=bh(T.p_hsi); T["q_alt"]=bh(T.p_alt)
fp = lambda p: "<0.001" if p<0.001 else f"{p:.3f}"
def rho(r,q_): 
    if np.isnan(r): return "—"
    star = "*" if q_<0.05 else ""
    return f"{r:+.2f}{star}"
tbl=[[r.var, r.nafld, r.non, f"{r.test}; {r.stat}", fp(r.p)+("" if r.q<0.05 else " (ns after FDR)"), rho(r.rho_hsi,r.q_hsi), rho(r.rho_alt,r.q_alt)] for r in T.itertuples()]
pd.set_option("display.width",250,"display.max_colwidth",60); print(T[["var","nafld","non","stat","p","q","rho_hsi","q_hsi","rho_alt","q_alt"]].round(4).to_string(index=False))
json.dump(dict(tbl=tbl), open("/home/claude/out/univar_tbl.json","w"))
# also: Table-1-type tests recap counts
t1 = pd.read_csv("/home/claude/out/table1.csv"); sig = (t1["p (unweighted)"].astype(str).str.replace("<","").astype(float) < 0.05).sum(); print("\nTable 1: variables with p<0.05:", sig, "of", len(t1))
print(t1[t1["p (unweighted)"].astype(str).str.replace("<","").astype(float) >= 0.05][["Variable","p (unweighted)"]].to_string(index=False))
