"""Nested 10-fold, tuned LightGBM for Set D vs Set E among plausible energy reporters (EI/BMR 0.9-2.5)."""
import json, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score
import ml_nested as M
u = pd.read_pickle("/home/claude/uniq.pkl")
d = M.d.merge(u[['ID', 'HE_ht', 'HE_wt']], on="ID", how="left", suffixes=("", "_u"))
bmr = np.where(d.sex == 1, 10 * d.HE_wt + 6.25 * d.HE_ht - 5 * d.age + 5, 10 * d.HE_wt + 6.25 * d.HE_ht - 5 * d.age - 161); d["ei_bmr"] = d.N_EN / bmr
ok = d[(d.ei_bmr >= 0.9) & (d.ei_bmr <= 2.5)].reset_index(drop=True)
M.d = ok; y = ok.nafld.values; groups = pd.factorize(ok.grp)[0]; outer = list(GroupKFold(10).split(ok, y, groups)); out = {}
for s in ["D", "E"]:
    oof = np.zeros(len(ok))
    for k, (tr, te) in enumerate(outer):
        p, bp, bs = M.fit_predict(s, "LightGBM", tr, te); oof[te] = p; print(s, k, round(roc_auc_score(y[te], p), 3), flush=True)
    out[s] = float(roc_auc_score(y, oof))
out["n"] = int(len(ok)); print(out); json.dump(out, open("/home/claude/out/nested_plausible.json", "w"))
