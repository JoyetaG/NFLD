#!/bin/bash
cd /home/claude
while pgrep -f "ml_nested.py" > /dev/null; do sleep 20; done
python3 nested_analysis.py > out/nested_analysis.log 2>&1
python3 nested_plausible.py > out/nested_plausible.log 2>&1
python3 nested_figures.py > out/nested_figures.log 2>&1
echo ALLDONE > out/pipeline_done.txt
