import pandas as pd, numpy as np, statsmodels.api as sm, warnings
warnings.filterwarnings("ignore")
dd = pd.read_pickle("/home/claude/out/extras_data.pkl").reset_index(drop=True)
g = pd.factorize(dd.grp)[0]
def fit(x, covs, dums, weighted):
    parts=[dd[[x]].astype(float)]
    if covs: parts.append(dd[covs].astype(float))
    if dums: parts.append(pd.get_dummies(dd[dums].astype(int).astype(str), drop_first=True).astype(float))
    X = sm.add_constant(pd.concat(parts,axis=1))
    w = dd.w if weighted else np.ones(len(dd))
    m = sm.GLM(dd.nafld, X, family=sm.families.Binomial(), freq_weights=w).fit(cov_type="cluster", cov_kwds={"groups": g})
    lo,hi=np.exp(m.conf_int().loc[x]); return f"{np.exp(m.params[x]):.2f} ({lo:.2f}-{hi:.2f})"
specs = [("crude",[],[]),("+age,sex",["age","female"],[]),("+smoking,activity",["age","female","smoker","active"],[]),("+edu,income,year (full)",["age","female","smoker","active"],["year","edu","incm"])]
for x,lab in [("fastfood_z","Fast-food index (per SD)"),("soda_z","Soda (per SD)"),("fat_pct_z","Fat %E (per SD)")]:
    print(f"\n{lab}")
    for nm,c,dm in specs:
        cc = [k for k in c]; 
        print(f"  {nm:26s} unweighted {fit(x,cc,dm,False):20s} weighted {fit(x,cc,dm,True)}")
x="inactive"; print("\nPhysical inactivity vs active")
for nm,c,dm in specs:
    cc=[k for k in c if k!="active"]; print(f"  {nm:26s} unweighted {fit(x,cc,dm,False):20s} weighted {fit(x,cc,dm,True)}")
# who eats fast food?
print("\nFast-food index by sex/age (mean z):", dd.groupby("female").fastfood_z.mean().round(2).to_dict(), dd.groupby(pd.cut(dd.age,[19,29,39,49,59,120])).fastfood_z.mean().round(2).to_dict())
print("NAFLD by sex:", dd.groupby("female").nafld.mean().round(3).to_dict())
