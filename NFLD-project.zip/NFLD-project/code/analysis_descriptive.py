import pandas as pd, numpy as np, statsmodels.api as sm
from scipy import stats
d = pd.read_pickle("/home/claude/out/analytic.pkl")
d["w"] = d.wt_tot / d.wt_tot.mean()

def design_ratio(y, w, strata, psu):
    """Taylor-linearised weighted proportion/mean with stratified PSU design."""
    y = np.asarray(y, float); w = np.asarray(w, float)
    p = (w*y).sum()/w.sum(); z = w*(y-p)/w.sum()
    df = pd.DataFrame(dict(z=z, h=strata.values, c=psu.values))
    cl = df.groupby(["h","c"]).z.sum().reset_index()
    var = 0.0
    for h, g in cl.groupby("h"):
        n = len(g)
        if n > 1: var += n/(n-1)*((g.z-g.z.mean())**2).sum()
    return p, np.sqrt(var)

p, se = design_ratio(d.nafld, d.w, d.kstrata, d.grp)
print(f"Weighted NAFLD (HSI>36) prevalence: {p*100:.1f}% (95% CI {100*(p-1.96*se):.1f}-{100*(p+1.96*se):.1f}); unweighted {d.nafld.mean()*100:.1f}%")
for sx, nm in [(1,"men"),(2,"women")]:
    m = d.sex==sx; pp, ss = design_ratio(d.nafld[m], d.w[m], d.kstrata[m], d.grp[m]); print(f"  {nm}: {pp*100:.1f}% ({100*(pp-1.96*ss):.1f}-{100*(pp+1.96*ss):.1f})")
res_prev = dict(w_prev=p, w_lo=p-1.96*se, w_hi=p+1.96*se, unw=d.nafld.mean())
pd.Series(res_prev).to_csv("/home/claude/out/prevalence.csv")

# ---------- Table 1 ----------
d["energy"] = d.N_EN; 
vars_ = [("Age (years)","age","ms"),("Female sex, %","female","pct"),("Current smoker, %","smoker","pct"),("Physically active, %","active","pct"),
 ("BMI (kg/m2)","HE_BMI","ms"),("Waist circumference (cm)","HE_wc","ms"),("ALT (IU/L)","HE_alt","med"),("AST (IU/L)","HE_ast","med"),
 ("Diabetes (diagnosed), %","diab","pct"),("Fasting glucose (mg/dL)","HE_glu","ms"),("Total cholesterol (mg/dL)","HE_chol","ms"),("HDL-C (mg/dL)","HE_HDL","ms"),
 ("Triglycerides (mg/dL)","HE_TG","med"),("SBP (mmHg)","HE_sbp","ms"),
 ("Energy (kcal/day)","N_EN","ms"),("Carbohydrate (g/day)","N_CHO","ms"),("Protein (g/day)","N_PROT","ms"),("Total fat (g/day)","N_FAT","ms"),
 ("Dietary fibre (g/day)","N_FIBER","med"),("Sodium (mg/day)","N_NA","med"),("Potassium (mg/day)","N_K","med"),("Calcium (mg/day)","N_CA","med"),
 ("Vitamin C (mg/day)","N_VITC","med"),("Water (mL/day)","N_WATER","med")]
rows=[]
a, b = d[d.nafld==1], d[d.nafld==0]
def fmt(s, kind):
    if kind=="ms": return f"{s.mean():.1f} ± {s.std():.1f}"
    if kind=="pct": return f"{s.mean()*100:.1f}%"
    q = s.quantile([.25,.5,.75]); return f"{q[.5]:.1f} ({q[.25]:.1f}–{q[.75]:.1f})"
for lab, c, kind in vars_:
    x, y = a[c].dropna(), b[c].dropna()
    pv = stats.chi2_contingency(pd.crosstab(d[c], d.nafld))[1] if kind=="pct" else stats.mannwhitneyu(x, y).pvalue
    wm_all = np.average(d[c].dropna(), weights=d.w[d[c].notna()])
    rows.append([lab, fmt(d[c].dropna(),kind), fmt(x,kind), fmt(y,kind), f"{wm_all:.2f}", "<0.001" if pv<0.001 else f"{pv:.3f}"])
t1 = pd.DataFrame(rows, columns=["Variable", f"Overall (n={len(d):,})", f"NAFLD (n={len(a):,})", f"Non-NAFLD (n={len(b):,})", "Weighted overall mean/prop", "p (unweighted)"])
t1.to_csv("/home/claude/out/table1.csv", index=False); print(t1.to_string(index=False))

# ---------- adjusted associations (design-robust logistic) ----------
inc = [("Dietary fibre","N_FIBER",5,"g/day"),("Sodium","N_NA",1000,"mg/day"),("Potassium","N_K",500,"mg/day"),("Vitamin C","N_VITC",50,"mg/day"),
       ("Calcium","N_CA",100,"mg/day"),("Total fat","N_FAT",10,"g/day"),("Carbohydrate","N_CHO",50,"g/day"),("Protein","N_PROT",10,"g/day"),
       ("Water","N_WATER",250,"mL/day"),("Energy","N_EN",500,"kcal/day")]
d["edu_c"]=d.edu; d["inc_c"]=d.incm
def fit(nutr, scale, covs, extra_dummies):
    X = pd.concat([ (d[nutr]/scale).rename("x"), d[covs].astype(float), pd.get_dummies(d[extra_dummies].astype(int).astype(str), prefix=extra_dummies, drop_first=True).astype(float)], axis=1)
    X = sm.add_constant(X)
    m = sm.GLM(d.nafld, X, family=sm.families.Binomial(), freq_weights=d.w).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(d.grp)[0]})
    b_, ci = m.params["x"], m.conf_int().loc["x"]; return np.exp(b_), np.exp(ci[0]), np.exp(ci[1]), m.pvalues["x"]
out=[]
for lab, c, sc, unit in inc:
    r = {"Nutrient": lab, "Increment": f"per {sc:g} {unit}"}
    specs = {"Model 1 (age, sex)": (["age","female"],["year"]),
             "Model 2 (+ smoking, activity, education, income)": (["age","female","smoker","active"],["year","edu","incm"]),
             "Model 3 (+ total energy)": (["age","female","smoker","active","N_EN"] if c!="N_EN" else ["age","female","smoker","active"],["year","edu","incm"]),
             "Model 3 + BMI (over-adjustment; BMI is in HSI)": (["age","female","smoker","active","HE_BMI"]+(["N_EN"] if c!="N_EN" else []),["year","edu","incm"])}
    for k,(covs,dum) in specs.items():
        o,l,h,pv = fit(c, sc, covs, dum); r[k] = f"{o:.2f} ({l:.2f}–{h:.2f})"; r[k+" p"] = pv
    out.append(r)
reg = pd.DataFrame(out); reg.to_csv("/home/claude/out/table_regression.csv", index=False)
print(reg[["Nutrient","Increment"]+[c for c in reg.columns if c.startswith("Model") and not c.endswith(" p")]].to_string(index=False))
