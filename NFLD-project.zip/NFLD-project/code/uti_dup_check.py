import pandas as pd, numpy as np, warnings
warnings.filterwarnings("ignore")
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score
raw = pd.read_pickle("/home/claude/knhanes.pkl"); u = pd.read_pickle("/home/claude/uniq.pkl")
diet = ['N_EN','N_WATER','N_PROT','N_FAT','N_CHO','N_FIBER','N_ASH','N_CA','N_PHOS','N_FE','N_NA','N_K','N_VA','N_CAROT','N_RETIN','N_B1','N_B2','N_NIAC','N_VITC']
oth = ['age','sex','HE_BMI','HE_glu','HE_chol','HE_TG','HE_HDL','HE_sbp','HE_dbp','HE_Uph','HE_Usg','HE_Upro','HE_Ubld','HE_Uglu']
feats = diet + oth
def run(df, name):
    df = df[df.HE_Unitr.notna()]; X = df[feats].values.astype(float); y = (df.HE_Unitr==1).astype(int).values
    pipe = make_pipeline(SimpleImputer(strategy="median"), ExtraTreesClassifier(200, min_samples_leaf=1, n_jobs=1, random_state=1))
    p = cross_val_predict(pipe, X, y, cv=StratifiedKFold(3, shuffle=True, random_state=1), method="predict_proba")[:,1]
    print(f"{name:55s} n={len(df):6d}  UTI+={y.sum():4d}  3-fold row-level CV AUROC = {roc_auc_score(y,p):.4f}", flush=True)
run(raw, "Supplied file as-is (duplicated rows)")
run(u,   "Deduplicated (one row per participant)")
