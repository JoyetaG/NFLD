"""Nested cross-validation for NAFLD (HSI > 36) classifiers.
Outer: 10-fold, folds grouped by primary sampling unit (PSU) -> out-of-fold (OOF) predictions.
Inner: 3-fold grouped CV inside each outer training set -> randomized hyperparameter search (scoring = ROC AUC).
All preprocessing (winsorising, log transform, scaling, one-hot encoding) is fitted inside the pipeline on training data only.
Usage: python ml_nested.py [--timing]   (resumable: completed set/model/fold results are cached)
"""
import sys, time, pickle, os, warnings, json
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder, FunctionTransformer
from sklearn.model_selection import GroupKFold, RandomizedSearchCV, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import roc_auc_score
import lightgbm as lgb, xgboost as xgb

OUT = "/home/claude/out/nested_cache.pkl"
d = pd.read_pickle("/home/claude/out/analytic.pkl").reset_index(drop=True)
d["yearn"] = d.year - 2008

# ---------------- feature engineering (row-wise, no fitted parameters -> no leakage) ----------------
d["prot_pct"] = d.N_PROT * 4 / d.N_EN * 100
d["fat_pct"] = d.N_FAT * 9 / d.N_EN * 100
d["cho_pct"] = d.N_CHO * 4 / d.N_EN * 100
d["fiber_dens"] = d.N_FIBER / d.N_EN * 1000
d["na_dens"] = d.N_NA / d.N_EN * 1000
d["k_dens"] = d.N_K / d.N_EN * 1000
d["na_k"] = d.N_NA / d.N_K
d["tg_hdl"] = d.HE_TG / d.HE_HDL
d["map"] = (d.HE_sbp + 2 * d.HE_dbp) / 3
DIET = ['N_EN', 'N_WATER', 'N_PROT', 'N_FAT', 'N_CHO', 'N_FIBER', 'N_ASH', 'N_CA', 'N_PHOS', 'N_FE', 'N_NA', 'N_K', 'N_VA', 'N_CAROT', 'N_RETIN', 'N_B1', 'N_B2', 'N_NIAC', 'N_VITC']
ENG_DIET = ['prot_pct', 'fat_pct', 'cho_pct', 'fiber_dens', 'na_dens', 'k_dens', 'na_k']
ENG_METAB = ['tg_hdl', 'map']
HSI_COMP = ['HE_BMI', 'HE_alt', 'HE_ast', 'diab', 'female']
LIFE = ['age', 'smoker', 'active', 'edu', 'incm', 'yearn']
METAB = ['HE_wc', 'HE_glu', 'HE_TG', 'HE_HDL', 'HE_chol', 'HE_sbp', 'HE_dbp']
SETS = {
    "A": HSI_COMP + LIFE + METAB + ENG_METAB + DIET + ENG_DIET,
    "B": LIFE + METAB + ENG_METAB + DIET + ENG_DIET,
    "C": LIFE + [m for m in METAB if m not in ('HE_wc', 'HE_glu')] + ENG_METAB + DIET + ENG_DIET,
    "D": LIFE + DIET + ENG_DIET,
    "E": LIFE,
}
CAT = ['edu', 'incm', 'yearn']
BIN = ['diab', 'female', 'smoker', 'active']
SKEW = set(DIET + ['HE_TG', 'HE_alt', 'HE_ast', 'tg_hdl', 'fiber_dens', 'na_dens', 'k_dens', 'na_k'])

class Winsor(BaseEstimator, TransformerMixin):
    """Clip each column to the 1st-99th percentile of the TRAINING data."""
    def __init__(self, lo=0.01, hi=0.99): self.lo, self.hi = lo, hi
    def fit(self, X, y=None):
        X = np.asarray(X, float); self.lo_ = np.quantile(X, self.lo, axis=0); self.hi_ = np.quantile(X, self.hi, axis=0); return self
    def transform(self, X): return np.clip(np.asarray(X, float), self.lo_, self.hi_)

def make_prep(cols):
    skew = [c for c in cols if c in SKEW]; cont = [c for c in cols if c not in SKEW and c not in CAT and c not in BIN]
    cat = [c for c in cols if c in CAT]; binc = [c for c in cols if c in BIN]
    parts = []
    if skew: parts.append(("skew", Pipeline([("w", Winsor()), ("log", FunctionTransformer(np.log1p)), ("s", StandardScaler())]), skew))
    if cont: parts.append(("cont", Pipeline([("w", Winsor()), ("s", StandardScaler())]), cont))
    if cat: parts.append(("cat", OneHotEncoder(drop="first", handle_unknown="ignore", sparse_output=False), cat))
    if binc: parts.append(("bin", "passthrough", binc))
    return ColumnTransformer(parts)

# ---------------- models and hyperparameter search spaces ----------------
def models():
    return {
        "LightGBM": (lgb.LGBMClassifier(verbose=-1, n_jobs=1, random_state=1, subsample_freq=1),
                     dict(n_estimators=[100, 200, 300], learning_rate=[0.03, 0.06, 0.1], num_leaves=[7, 15, 31], min_child_samples=[20, 50, 100], subsample=[0.7, 0.85, 1.0], colsample_bytree=[0.6, 0.8, 1.0], reg_lambda=[0, 1, 10]), 6),
        "XGBoost": (xgb.XGBClassifier(n_jobs=1, random_state=1, eval_metric="logloss", tree_method="hist"),
                    dict(n_estimators=[100, 200, 300], learning_rate=[0.03, 0.06, 0.1], max_depth=[3, 4, 6], min_child_weight=[1, 5, 20], subsample=[0.7, 0.85, 1.0], colsample_bytree=[0.6, 0.8, 1.0], reg_lambda=[1, 10]), 5),
        "Random Forest": (RandomForestClassifier(n_estimators=60, n_jobs=1, random_state=1, max_samples=0.7),
                          dict(max_depth=[6, 10, 16], min_samples_leaf=[5, 15, 40], max_features=["sqrt", 0.4]), 3),
        "MLP": (MLPClassifier(early_stopping=True, max_iter=150, random_state=1, n_iter_no_change=8),
                dict(hidden_layer_sizes=[(32,), (64, 32), (128, 64)], alpha=[1e-4, 1e-3, 1e-2], learning_rate_init=[1e-3, 3e-3]), 3),
        "Logistic Regression": (LogisticRegression(max_iter=2000), dict(C=[0.01, 0.1, 1.0, 10.0]), None),
        "KNN": (KNeighborsClassifier(), dict(n_neighbors=[15, 31, 61, 101], weights=["uniform", "distance"]), 4),
        "Decision Tree": (DecisionTreeClassifier(random_state=1), dict(max_depth=[3, 5, 8, 12], min_samples_leaf=[10, 30, 100], ccp_alpha=[0, 1e-4, 1e-3]), 6),
        "Gaussian NB": (GaussianNB(), dict(var_smoothing=[1e-9, 1e-8, 1e-7, 1e-6]), None),
    }

def fit_predict(set_name, model_name, tr, te):
    cols = SETS[set_name]; base, grid, n_iter = models()[model_name]
    pipe = Pipeline([("prep", make_prep(cols)), ("model", base)])
    pgrid = {"model__" + k: v for k, v in grid.items()}
    Xtr, ytr, gtr = d.loc[tr, cols], d.nafld.values[tr], pd.factorize(d.grp.values[tr])[0]
    inner = list(GroupKFold(3).split(Xtr, ytr, gtr))
    if n_iter is None: search = GridSearchCV(pipe, pgrid, cv=inner, scoring="roc_auc", n_jobs=1, refit=True)
    else: search = RandomizedSearchCV(pipe, pgrid, n_iter=n_iter, cv=inner, scoring="roc_auc", n_jobs=1, refit=True, random_state=7)
    search.fit(Xtr, ytr)
    p = search.predict_proba(d.loc[te, cols])[:, 1]
    return p, {k.replace("model__", ""): (v if isinstance(v, (int, float, str, tuple)) else str(v)) for k, v in search.best_params_.items()}, float(search.best_score_)

if __name__ == "__main__":
    y = d.nafld.values; groups = pd.factorize(d.grp)[0]
    outer = list(GroupKFold(10).split(d, y, groups))
    cache = pickle.load(open(OUT, "rb")) if os.path.exists(OUT) else {}
    timing = "--timing" in sys.argv
    only_sets = [a.split("=")[1] for a in sys.argv if a.startswith("--sets=")]
    sets = list(only_sets[0].split(",")) if only_sets else list(SETS)
    t0 = time.time()
    for sname in sets:
        for mname in models():
            for k, (tr, te) in enumerate(outer):
                key = (sname, mname, k)
                if key in cache: continue
                t1 = time.time(); p, bp, bs = fit_predict(sname, mname, tr, te)
                cache[key] = dict(te=te, p=p, params=bp, inner_auc=bs, sec=time.time() - t1)
                pickle.dump(cache, open(OUT, "wb"))
                print(f"{time.time()-t0:7.0f}s set {sname} {mname:20s} fold {k}: outer AUC {roc_auc_score(y[te], p):.3f} inner {bs:.3f} ({time.time()-t1:.0f}s) {bp}", flush=True)
                if timing: break
            if timing: pass
        if timing: break
    print("DONE", flush=True)
