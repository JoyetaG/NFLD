import pandas as pd, numpy as np, json, warnings
warnings.filterwarnings("ignore")
from scipy import stats
dd = pd.read_pickle("/home/claude/out/extras_data.pkl").reset_index(drop=True)
dd["fastfood"] = dd.F_HAMBER + dd.F_PIZZA + dd.F_FRIED
T = json.load(open("/home/claude/out/univar_tbl.json"))["tbl"]
names = [("N_FIBER"),("N_NA"),("N_K"),("N_EN"),("N_FAT"),("fat_pct"),("fastfood"),("F_HAMBER"),("F_PIZZA"),("F_FRIED"),("F_SODA"),("HE_vitD"),("urineNa_excretion"),("inactive")]
def partial_spearman(x, y, covs):
    m = pd.concat([x,y,covs],axis=1).dropna(); rx = m.iloc[:,0].rank(); ry = m.iloc[:,1].rank(); C = np.column_stack([np.ones(len(m)), m.iloc[:,2:].values.astype(float)])
    ex = rx.values - C@np.linalg.lstsq(C, rx.values, rcond=None)[0]; ey = ry.values - C@np.linalg.lstsq(C, ry.values, rcond=None)[0]
    r = np.corrcoef(ex,ey)[0,1]; n=len(m); t = r*np.sqrt((n-2-C.shape[1]+1)/(1-r**2)); p = 2*stats.t.sf(abs(t), n-2-(C.shape[1]-1)); return r,p
res={}
for c in names:
    r1,p1 = partial_spearman(dd[c], dd.HSI, dd[["age","female"]]); r2,p2 = partial_spearman(dd[c], dd.HE_alt, dd[["age","female"]])
    res[c]=(r1,p1,r2,p2)
def bh(p):
    p=np.asarray(p,float); n=len(p); o=np.argsort(p); r=p[o]*n/(np.arange(n)+1); r=np.minimum.accumulate(r[::-1])[::-1]; out=np.empty(n); out[o]=np.minimum(r,1); return out
q1 = bh([res[c][1] for c in names]); q2 = bh([res[c][3] for c in names])
for i,c in enumerate(names):
    print(f"{c:18s} partial rho HSI {res[c][0]:+.3f} (q={q1[i]:.4f}) | partial rho ALT {res[c][2]:+.3f} (q={q2[i]:.4f})")
f = lambda r,q: f"{r:+.2f}{'*' if q<0.05 else ''}"
# rebuild table: add adjusted rho columns; drop the tertile row's rho
out=[]
for i,row in enumerate(T):
    if i < len(names): out.append(row[:5] + [row[5], f(res[names[i]][0], q1[i]), row[6], f(res[names[i]][2], q2[i])])
    else: out.append(row[:5] + ["—","—","—","—"])
json.dump(dict(tbl=out), open("/home/claude/out/univar_tbl2.json","w")); print(out[6]); print(out[-2])
