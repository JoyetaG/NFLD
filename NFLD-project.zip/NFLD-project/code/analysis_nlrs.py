import pandas as pd, numpy as np, warnings, statsmodels.api as sm, pickle
warnings.filterwarnings("ignore")
from sklearn.linear_model import LogisticRegressionCV, LogisticRegression
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from scipy import stats

d = pd.read_pickle("/home/claude/out/analytic.pkl").reset_index(drop=True)
d["yearn"] = d.year - 2008
nut = ['N_WATER','N_PROT','N_FAT','N_CHO','N_FIBER','N_ASH','N_CA','N_PHOS','N_FE','N_NA','N_K','N_VA','N_CAROT','N_RETIN','N_B1','N_B2','N_NIAC','N_VITC']
lab = dict(N_WATER="Water",N_PROT="Protein",N_FAT="Total fat",N_CHO="Carbohydrate",N_FIBER="Dietary fibre",N_ASH="Ash",N_CA="Calcium",N_PHOS="Phosphorus",N_FE="Iron",N_NA="Sodium",N_K="Potassium",N_VA="Vitamin A",N_CAROT="Carotene",N_RETIN="Retinol",N_B1="Thiamin (B1)",N_B2="Riboflavin (B2)",N_NIAC="Niacin",N_VITC="Vitamin C")
# nutrient density (per 1000 kcal); log1p to tame skew
for c in nut: d[c+"_nd"] = np.log1p(d[c] / d.N_EN * 1000)
nd = [c+"_nd" for c in nut]
covs = ["age","female","smoker","active"]

def hosmer_lemeshow(y, p, g=10):
    q = pd.qcut(p, g, duplicates="drop"); t = pd.DataFrame(dict(y=y, p=p, q=q))
    a = t.groupby("q").agg(o=("y","sum"), e=("p","sum"), n=("y","size"))
    hl = (((a.o-a.e)**2)/(a.e*(1-a.e/a.n))).sum(); return hl, stats.chi2.sf(hl, len(a)-2)

def run(dev, val, name):
    sc = StandardScaler().fit(dev[nd]); Xd = sc.transform(dev[nd]); Xv = sc.transform(val[nd])
    cv = GroupKFold(10).split(Xd, dev.nafld, pd.factorize(dev.grp)[0])
    lasso = LogisticRegressionCV(Cs=25, cv=list(cv), penalty="l1", solver="liblinear", scoring="roc_auc", max_iter=500, random_state=1).fit(Xd, dev.nafld)
    coef = pd.Series(lasso.coef_[0], index=nut); sel = coef[coef != 0].index.tolist()
    # unpenalised multivariable model for weights (selected nutrients standardised + covariates)
    Z = pd.DataFrame(Xd, columns=nut, index=dev.index)[sel]
    Xm = sm.add_constant(pd.concat([Z, dev[covs].astype(float)], axis=1))
    mm = sm.Logit(dev.nafld, Xm).fit(disp=0)
    beta = mm.params[sel]; wts = np.round(10*beta.abs()/beta.abs().max()).astype(int)
    # percentile-based points using derivation distribution
    def score(df):
        s = 0
        for c in sel:
            pr = np.searchsorted(np.sort(dev[c+"_nd"]), df[c+"_nd"]) / len(dev)
            pr = pr if beta[c] > 0 else 1 - pr
            s = s + wts[c] * pr
        return 100 * s / wts.sum()
    sd_, sv_ = score(dev), score(val)
    lab_tbl = pd.DataFrame(dict(Nutrient=[lab[c] for c in sel], Direction=np.where(beta>0,"Risk","Protective"), LASSO_coef=coef[sel].values.round(3), aOR_per_SD=np.exp(beta).round(2).values, CI_lo=np.exp(mm.conf_int().loc[sel,0]).round(2).values, CI_hi=np.exp(mm.conf_int().loc[sel,1]).round(2).values, p=mm.pvalues[sel].round(4).values, Weight_0_10=wts.values))
    auc = roc_auc_score(val.nafld, sv_)
    rng = np.random.default_rng(3); ug = val.grp.unique(); idx = {g: np.where(val.grp.values==g)[0] for g in ug}
    ba=[]
    for _ in range(300):
        b = np.concatenate([idx[g] for g in rng.choice(ug, len(ug))]); ba.append(roc_auc_score(val.nafld.values[b], sv_.values[b] if hasattr(sv_,'values') else sv_[b]))
    # covariate-only baseline vs covariates + NLRS
    lr0 = LogisticRegression(max_iter=1000).fit(dev[covs], dev.nafld); auc0 = roc_auc_score(val.nafld, lr0.predict_proba(val[covs])[:,1])
    dev2 = dev[covs].assign(s=sd_); val2 = val[covs].assign(s=sv_)
    lr1 = LogisticRegression(max_iter=1000).fit(dev2, dev.nafld); p1 = lr1.predict_proba(val2)[:,1]; auc1 = roc_auc_score(val.nafld, p1)
    hl, hlp = hosmer_lemeshow(val.nafld.values, p1)
    # quintile ORs in validation (adjusted for age, sex, smoking, activity); cut points from derivation
    cuts = np.quantile(sd_, [.2,.4,.6,.8]); qv = np.digitize(sv_, cuts)
    Xq = pd.get_dummies(pd.Series(qv, index=val.index).astype(str), prefix="Q", drop_first=True).astype(float)
    Xq = sm.add_constant(pd.concat([Xq, val[covs].astype(float)], axis=1))
    mq = sm.GLM(val.nafld, Xq, family=sm.families.Binomial()).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(val.grp)[0]})
    qor = [(1.0,1.0,1.0)] + [(np.exp(mq.params[f"Q_{k}"]), *np.exp(mq.conf_int().loc[f"Q_{k}"])) for k in range(1,5)]
    Xt = sm.add_constant(pd.concat([pd.Series(qv, index=val.index, name="qtrend").astype(float), val[covs].astype(float)], axis=1))
    mt = sm.GLM(val.nafld, Xt, family=sm.families.Binomial()).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(val.grp)[0]})
    # calibration deciles
    cal = pd.DataFrame(dict(p=p1, y=val.nafld.values)); cal["q"]=pd.qcut(cal.p,10,duplicates="drop"); cal = cal.groupby("q").agg(pred=("p","mean"), obs=("y","mean"))
    print(f"\n=== NLRS {name}: derivation n={len(dev):,} (NAFLD {dev.nafld.mean()*100:.1f}%), validation n={len(val):,} (NAFLD {val.nafld.mean()*100:.1f}%)")
    print(lab_tbl.to_string(index=False))
    print(f"NLRS alone AUROC (validation) = {auc:.3f} (95% CI {np.percentile(ba,2.5):.3f}-{np.percentile(ba,97.5):.3f}); age/sex/smoking/activity only = {auc0:.3f}; covariates + NLRS = {auc1:.3f}")
    print(f"Hosmer-Lemeshow (covariates+NLRS model) chi2={hl:.2f}, p={hlp:.3f}; quintile aORs Q1..Q5:", [f"{a:.2f} ({b:.2f}-{c:.2f})" for a,b,c in qor], f"p-trend={mt.pvalues['qtrend']:.3f}")
    return dict(tbl=lab_tbl, auc=auc, ci=(np.percentile(ba,2.5), np.percentile(ba,97.5)), auc0=auc0, auc1=auc1, hl=(hl,hlp), qor=qor, ptrend=mt.pvalues["qtrend"], cal=cal, score_val=sv_, y_val=val.nafld.values, n=(len(dev),len(val)), sel=sel)

dev_t, val_t = d[d.year <= 2009], d[d.year >= 2010]
R_temporal = run(dev_t, val_t, "TEMPORAL (derive 2008-09 -> validate 2010-11)")
rng = np.random.default_rng(11); ug = d.grp.unique(); dv = set(rng.choice(ug, int(0.7*len(ug)), replace=False))
m = d.grp.isin(dv); R_random = run(d[m], d[~m], "RANDOM 70/30 by PSU (same-survey hold-out; internal only)")
pickle.dump(dict(temporal=R_temporal, random=R_random), open("/home/claude/out/nlrs.pkl","wb"))
