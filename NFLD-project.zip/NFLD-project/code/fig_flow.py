import pandas as pd, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
NAVY, TEAL, RED = "#1B3A6B", "#0E7C7B", "#C0392B"
d = pd.read_pickle("/home/claude/out/analytic.pkl"); fl = pd.read_csv("/home/claude/out/flow.csv")
steps = fl.iloc[1:].reset_index(drop=True); n = len(steps); dy = 1.15
fig, ax = plt.subplots(figsize=(11, 13)); ax.axis("off"); ax.set_xlim(0, 11); ax.set_ylim(-2.2, n*dy+0.6)
short = ["Readable rows in supplied file", "After removing duplicate records\n(all 2010 and 2011 records were duplicated)", "After excluding age < 19 y\n(minimum age in file is 20; none excluded)", "After excluding missing HSI inputs\n(ALT, AST, BMI, diabetes)", "After excluding missing 24-h recall", "After excluding HBsAg-positive", "After excluding heavy-alcohol flag", "After excluding pregnancy", "After excluding implausible energy\n(<500 or >5,000 kcal/day)", "Final analytic sample\n(after excluding missing covariates)"]
for i, r in steps.iterrows():
    yy = n*dy - i*dy; fin = i == n-1
    ax.add_patch(plt.Rectangle((0.6, yy-0.45), 5.6, 0.9, fc="#E0F0EF" if fin else "#E6EEF8", ec=TEAL if fin else NAVY, lw=1.6))
    two = "\n" in short[i]
    ax.text(3.4, yy+(0.17 if two else 0.13), short[i], ha="center", va="center", fontsize=9, fontweight="bold", color=NAVY, linespacing=1.15)
    ax.text(3.4, yy-(0.30 if two else 0.2), f"n = {int(r.remaining):,}", ha="center", va="center", fontsize=9, style="italic", color=NAVY)
    if i > 0 and r.excluded > 0:
        ax.add_patch(plt.Rectangle((6.9, yy-0.3), 3.8, 0.6, fc="#FDECEA", ec=RED, lw=1.2)); ax.text(8.8, yy, f"Excluded n = {int(r.excluded):,}", ha="center", va="center", fontsize=9, color=RED)
        ax.annotate("", xy=(6.2, yy), xytext=(6.9, yy), arrowprops=dict(arrowstyle="->", color=RED))
    if i < n-1: ax.annotate("", xy=(3.4, yy-dy+0.45), xytext=(3.4, yy-0.45), arrowprops=dict(arrowstyle="->", color=NAVY))
yb = n*dy - (n-1)*dy - 1.5
ax.annotate("", xy=(1.9, yb+0.55), xytext=(1.9, 0.55-0.0), arrowprops=dict(arrowstyle="->", color=NAVY)); ax.annotate("", xy=(4.9, yb+0.55), xytext=(4.9, 0.55), arrowprops=dict(arrowstyle="->", color=NAVY))
ax.add_patch(plt.Rectangle((0.6, yb-0.45), 2.6, 1.0, fc="#FDECEA", ec=RED, lw=1.4)); ax.text(1.9, yb+0.05, f"NAFLD (HSI > 36)\nn = {int(d.nafld.sum()):,}\n{d.nafld.mean()*100:.1f}% (22.2% weighted)", ha="center", va="center", fontsize=8.5, color=RED, fontweight="bold")
ax.add_patch(plt.Rectangle((3.6, yb-0.45), 2.6, 1.0, fc="#E0F0EF", ec=TEAL, lw=1.4)); ax.text(4.9, yb+0.05, f"Non-NAFLD\nn = {int((1-d.nafld).sum()):,}", ha="center", va="center", fontsize=9, color=TEAL, fontweight="bold")
ax.set_title("Figure 1. Participant flow — KNHANES 2008–2011 (rebuilt from the supplied dataset)", fontweight="bold", color=NAVY, fontsize=12)
plt.savefig("/mnt/user-data/outputs/Fig1_participant_flow.png", dpi=170, bbox_inches="tight"); plt.close()
