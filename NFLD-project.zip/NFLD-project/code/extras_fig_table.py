import json, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
NAVY, TEAL, RED, GOLD = "#1B3A6B", "#0E7C7B", "#C0392B", "#C8963E"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
E = json.load(open("/home/claude/out/extras.json")); dd = pd.read_pickle("/home/claude/out/extras_data.pkl")
sd = dict(fat=dd.fat_pct.std(), vitd=dd.HE_vitD.std(), una=dd.urineNa_excretion.std())
f = lambda t: f"{t[0]:.2f} ({t[1]:.2f}–{t[2]:.2f})"
rows = [("Fat, % of energy", f"per SD ({sd['fat']:.1f} percentage points)", "fat", "fat_pct"),
        ("Fast-food index (hamburger, pizza, fried food)", "per SD", "fastfood", "fastfood"),
        ("Soda frequency", "per SD", "soda", "soda"),
        ("Physical inactivity", "vs active", "inactive", "inactive"),
        ("Serum 25-hydroxyvitamin D", f"per SD ({sd['vitd']:.1f} ng/mL)", "vitd", None),
        ("Estimated 24-h urinary sodium", f"per SD ({sd['una']:.0f} mEq/day)", "una", None)]
tbl = []
for lab, inc, k, mk in rows:
    r = [lab, inc]
    for y in ["nafld","alt_high"]:
        r.append(f(E[y][k])); r.append(f(E[y]["mut"][mk]) if mk else "—")
    tbl.append(r)
json.dump(dict(tbl=tbl, sd={k:float(v) for k,v in sd.items()}), open("/home/claude/out/extras_tbl.json","w")); print(tbl)
fig, ax = plt.subplots(1, 2, figsize=(13.5, 5.6), sharey=True)
labs = [r[0] for r in rows][::-1]; ypos = np.arange(len(rows))[::-1]
for a, (y, ttl) in zip(ax, [("nafld","A. NAFLD (HSI > 36)"),("alt_high","B. Elevated ALT (BMI-independent)")]):
    for yy,(lab,inc,k,mk) in zip(ypos, rows):
        o,l,h,_ = E[y][k]; a.plot([l,h],[yy+.13]*2,color=TEAL,lw=2.2); a.plot(o,yy+.13,"D",color=TEAL,ms=6)
        if mk: o2,l2,h2,_ = E[y]["mut"][mk]; a.plot([l2,h2],[yy-.13]*2,color=GOLD,lw=2.2); a.plot(o2,yy-.13,"s",color=GOLD,ms=5.5)
    a.axvline(1,color="k",ls="--",lw=1); a.set_xlim(0.85,1.5); a.set_xlabel("Adjusted odds ratio (95% CI)"); a.set_title(ttl, fontweight="bold", color=NAVY)
ax[0].set_yticks(ypos); ax[0].set_yticklabels([f"{r[0]}\n({r[1]})" for r in rows], fontsize=8.5)
fig.legend(handles=[Line2D([0],[0],color=TEAL,marker="D",label="Each exposure modelled separately"),Line2D([0],[0],color=GOLD,marker="s",label="Mutually adjusted (fat, fast food, soda, inactivity)")], loc="lower center", ncol=2, frameon=False)
plt.tight_layout(rect=(0,0.06,1,1)); plt.savefig("/mnt/user-data/outputs/Figure8_Fat_FastFood_Inactivity.png", dpi=170); plt.close()
