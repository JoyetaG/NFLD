import json, numpy as np, pandas as pd, statsmodels.api as sm, warnings
warnings.filterwarnings("ignore")
dd = pd.read_pickle("/home/claude/out/extras_data.pkl").reset_index(drop=True)
E = json.load(open("/home/claude/out/extras.json"))
z = lambda s: (s - s.mean()) / s.std()
dd["fibre_z"] = z(dd.N_FIBER); dd["na_z"] = z(dd.N_NA); dd["k_z"] = z(dd.N_K)
dd["ln_alt"] = np.log(dd.HE_alt); dd["ln_ast"] = np.log(dd.HE_ast)
dd["male"] = (1 - dd.female).astype(int); dd["age50"] = (dd.age >= 50).astype(int)
out = {"n": int(len(dd)), "alt_high_prev": float(dd.alt_high.mean()), "nafld_prev": float(dd.nafld.mean())}
DUM = ["year", "edu", "incm"]
def design(data, xcols, covs):
    parts = [data[xcols].astype(float), data[covs].astype(float), pd.get_dummies(data[DUM].astype(int).astype(str), drop_first=True).astype(float)]
    return sm.add_constant(pd.concat(parts, axis=1))
def cov_list(drop_active=False, extra=(), drop=()):
    c = ["age", "female", "smoker"] + ([] if drop_active else ["active"]) + list(extra)
    return [x for x in c if x not in drop]
# ================= 1. continuous liver enzymes (weighted least squares on ln ALT / ln AST) =================
EXPO = [("Fat, % of energy (per SD)", "fat_pct_z", False, []), ("Fast-food index (per SD)", "fastfood_z", False, []), ("Soda frequency (per SD)", "soda_z", False, []),
        ("Physical inactivity (vs active)", "inactive", True, []), ("Dietary fibre (per SD)", "fibre_z", False, ["N_EN"]), ("Sodium (per SD)", "na_z", False, ["N_EN"]),
        ("Potassium (per SD)", "k_z", False, ["N_EN"]), ("Serum 25-hydroxyvitamin D (per SD)", "vitd_z", False, [])]
rows = []
for lab, x, da, ex in EXPO:
    data = dd.dropna(subset=[x]); g = pd.factorize(data.grp)[0]; r = [lab]
    for y in ["ln_alt", "ln_ast"]:
        for bmi in (False, True):
            X = design(data, [x], cov_list(da, ex + (["HE_BMI"] if bmi else [])))
            m = sm.WLS(data[y], X, weights=data.w).fit(cov_type="cluster", cov_kwds={"groups": g})
            b = m.params[x]; lo, hi = m.conf_int().loc[x]; r.append(f"{(np.exp(b)-1)*100:+.1f}% ({(np.exp(lo)-1)*100:+.1f} to {(np.exp(hi)-1)*100:+.1f})")
            r.append(m.pvalues[x])
    rows.append(r)
out["continuous"] = [[r[0], r[1], r[3], r[5], r[7]] for r in rows]; out["continuous_p"] = [[r[2], r[4], r[6], r[8]] for r in rows]
# ================= 2. effect modification by sex and age =================
def logit(data, y, x, covs):
    X = design(data, [x], covs); g = pd.factorize(data.grp)[0]
    m = sm.GLM(data[y], X, family=sm.families.Binomial(), freq_weights=data.w).fit(cov_type="cluster", cov_kwds={"groups": g})
    lo, hi = np.exp(m.conf_int().loc[x]); return float(np.exp(m.params[x])), float(lo), float(hi), float(m.pvalues[x])
def inter_p(data, y, x, mod, covs):
    """Interaction test from a fully interacted model: every covariate (and the exposure) is allowed a different effect across levels of the moderator."""
    d2 = data.copy(); base = design(d2, [x], [c for c in covs if c != mod]).drop(columns="const")
    inter = base.mul(d2[mod].astype(float), axis=0); inter.columns = [c + "__x" + mod for c in base.columns]
    X = sm.add_constant(pd.concat([base, d2[[mod]].astype(float), inter], axis=1)); g = pd.factorize(d2.grp)[0]
    m = sm.GLM(d2[y], X, family=sm.families.Binomial(), freq_weights=d2.w).fit(cov_type="cluster", cov_kwds={"groups": g}); return float(m.pvalues[x + "__x" + mod])
em = []
f = lambda t: f"{t[0]:.2f} ({t[1]:.2f}–{t[2]:.2f})"
for lab, x, da in [("Soda frequency (per SD)", "soda_z", False), ("Fast-food index (per SD)", "fastfood_z", False), ("Fat, % of energy (per SD)", "fat_pct_z", False), ("Physical inactivity (vs active)", "inactive", True)]:
    for y, yl in [("nafld", "NAFLD"), ("alt_high", "Elevated ALT")]:
        men = logit(dd[dd.male == 1], y, x, cov_list(da, drop=("female",))); wom = logit(dd[dd.male == 0], y, x, cov_list(da, drop=("female",)))
        yng = logit(dd[dd.age50 == 0], y, x, cov_list(da)); old = logit(dd[dd.age50 == 1], y, x, cov_list(da))
        p_sex = inter_p(dd, y, x, "male", cov_list(da, drop=("female",)) + ["male"]); p_age = inter_p(dd, y, x, "age50", cov_list(da) + ["age50"])
        em.append([lab, yl, f(men), f(wom), f"{p_sex:.3f}", f(yng), f(old), f"{p_age:.3f}"])
out["effect_mod"] = em
# ================= 3. E-values =================
def evalue(rr):
    rr = 1 / rr if rr < 1 else rr
    return rr + np.sqrt(rr * (rr - 1))
def ev_row(label, o, lo, hi, prev):
    conv = (lambda v: np.sqrt(v)) if prev > 0.10 else (lambda v: v)
    rr = conv(o); pt = evalue(rr)
    near = lo if o > 1 else hi
    ci = 1.0 if (lo <= 1 <= hi) else evalue(conv(near))
    return [label, f"{o:.2f} ({lo:.2f}–{hi:.2f})", "RR ≈ √OR" if prev > 0.10 else "RR ≈ OR", f"{pt:.2f}", f"{ci:.2f}"]
pn, pa = out["nafld_prev"], out["alt_high_prev"]
ev = [ev_row("Soda frequency, NAFLD", *E["nafld"]["soda"][:3], pn), ev_row("Soda frequency, elevated ALT", *E["alt_high"]["soda"][:3], pa),
      ev_row("Physical inactivity, NAFLD", *E["nafld"]["inactive"][:3], pn), ev_row("Physical inactivity, elevated ALT", *E["alt_high"]["inactive"][:3], pa),
      ev_row("Fast-food index, NAFLD (weighted)", *E["nafld"]["fastfood"][:3], pn), ev_row("Fast-food index, NAFLD (unweighted)", 1.05, 1.00, 1.10, pn),
      ev_row("Serum vitamin D, NAFLD", *E["nafld"]["vitd"][:3], pn)]
out["evalues"] = ev
# ================= 4. measurement-error scenarios (classical error; corrected OR = OR^(1/reliability)) =================
def nafld_or(x, extra):
    data = dd.dropna(subset=[x]); return logit(data, "nafld", x, cov_list(False, extra))
me_src = {"Dietary fibre (24-h recall, per SD)": nafld_or("fibre_z", ["N_EN"]), "Sodium (24-h recall, per SD)": nafld_or("na_z", ["N_EN"]), "Potassium (24-h recall, per SD)": nafld_or("k_z", ["N_EN"]),
          "Fat, % of energy (24-h recall, per SD)": tuple(E["nafld"]["fat"][:4]), "Fast-food index (frequency, per SD)": tuple(E["nafld"]["fastfood"][:4]), "Soda frequency (per SD)": tuple(E["nafld"]["soda"][:4])}
me = []
for lab, (o, lo, hi, p) in me_src.items():
    row = [lab, f"{o:.2f} ({lo:.2f}–{hi:.2f})"]
    for lam in (0.7, 0.5, 0.3):
        row.append(f"{o ** (1 / lam):.2f} ({lo ** (1 / lam):.2f}–{hi ** (1 / lam):.2f})")
    me.append(row)
out["meas_error"] = me
json.dump(out, open("/home/claude/out/causal_extras.json", "w"), indent=1, default=float)
print("elevated ALT prevalence %.3f, NAFLD %.3f" % (pa, pn))
for r in out["continuous"]: print(r)
for r in em: print(r)
for r in ev: print(r)
for r in me: print(r)
