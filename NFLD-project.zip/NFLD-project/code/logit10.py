import pandas as pd, numpy as np, warnings
warnings.filterwarnings("ignore")
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score
dd = pd.read_pickle("/home/claude/out/extras_data.pkl").reset_index(drop=True); dd["yearn"]=dd.year-2008
base = ["age","female","smoker","active","edu","incm","yearn"]; y = dd.nafld.values; g = pd.factorize(dd.grp)[0]
folds = list(GroupKFold(10).split(dd, y, g))
def cv(cols):
    X = dd[cols].values.astype(float); oof = np.zeros(len(dd))
    for tr, te in folds:
        m = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)).fit(X[tr], y[tr]); oof[te] = m.predict_proba(X[te])[:,1]
    return roc_auc_score(y, oof)
print("10-fold grouped, logistic AUROC: covariates %.3f | + fat %%E %.3f | + fast-food %.3f | + both %.3f" % (cv(base), cv(base+["fat_pct"]), cv(base+["fastfood_z"]), cv(base+["fat_pct","fastfood_z"])))
