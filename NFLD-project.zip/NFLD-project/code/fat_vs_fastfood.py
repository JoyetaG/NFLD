import pandas as pd, numpy as np, statsmodels.api as sm, warnings
warnings.filterwarnings("ignore")
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
u = pd.read_pickle("/home/claude/uniq.pkl"); d = pd.read_pickle("/home/claude/out/analytic.pkl").reset_index(drop=True)
F = ['F_HAMBER','F_PIZZA','F_FRIED','F_SODA']
d = d.merge(u[['ID']+F], on="ID", how="left", suffixes=("","_u"))
for c in F: d.loc[d[c]>=90, c]=np.nan
d = d.dropna(subset=F).reset_index(drop=True); d["w"]=d.wt_tot/d.wt_tot.mean()
d["fat_pct"] = d.N_FAT*9/d.N_EN*100                       # fat as % of energy
z = lambda s: (s-s.mean())/s.std()
d["fastfood"] = z(d.F_HAMBER)+z(d.F_PIZZA)+z(d.F_FRIED)    # fast-food/fried index (sum of z-scores)
d["ff_z"] = z(d.fastfood); d["fat_pct_z"]=z(d.fat_pct); d["fat_g_z"]=z(d.N_FAT); d["soda_z"]=z(d.F_SODA)
alt_thr = np.where(d.sex==1, 33, 25); d["alt_high"] = (d.HE_alt > alt_thr).astype(int)   # BMI-free liver outcome (ALT above sex-specific limit)
print(f"n={len(d):,} | NAFLD(HSI>36) {d.nafld.mean()*100:.1f}% | elevated ALT {d.alt_high.mean()*100:.1f}% | fat mean {d.N_FAT.mean():.1f} g ({d.fat_pct.mean():.1f}% energy; SD {d.fat_pct.std():.1f}) ")
print("fast-food items (category codes): mean", d[['F_HAMBER','F_PIZZA','F_FRIED']].mean().round(2).to_dict(), "| corr(fat%E, fast-food index) =", round(d[['fat_pct','fastfood']].corr().iloc[0,1],2))
base = ["age","female","smoker","active"]; dums=["year","edu","incm"]
grp = pd.factorize(d.grp)[0]
def fit(y, xs, extra=[]):
    X = sm.add_constant(pd.concat([d[xs].astype(float), d[base+extra].astype(float), pd.get_dummies(d[dums].astype(int).astype(str), drop_first=True).astype(float)],axis=1))
    m = sm.GLM(d[y], X, family=sm.families.Binomial(), freq_weights=d.w).fit(cov_type="cluster", cov_kwds={"groups": grp})
    return {x: (np.exp(m.params[x]), *np.exp(m.conf_int().loc[x]), m.pvalues[x]) for x in xs}
fmt = lambda t: f"{t[0]:.2f} ({t[1]:.2f}-{t[2]:.2f}) p={t[3]:.3g}"
print("\n=== Odds ratio per 1 SD (survey-weighted; base covariates: age, sex, smoking, activity, education, income, year)")
for y, nm in [("nafld","NAFLD (HSI>36)"),("alt_high","Elevated ALT (BMI-free outcome)")]:
    print(f"\n-- outcome: {nm}")
    for lab, xs, ex in [("Fat % energy alone",["fat_pct_z"],[]),("Fast-food index alone",["ff_z"],[]),("Soda frequency alone",["soda_z"],[]),
                        ("BOTH mutually adjusted: fat %E",["fat_pct_z","ff_z"],[]),
                        ("BOTH + total energy",["fat_pct_z","ff_z"],["N_EN"]),("BOTH + energy + BMI (over-adjusted)",["fat_pct_z","ff_z"],["N_EN","HE_BMI"])]:
        r = fit(y, xs, ex); print(f"   {lab:38s}", " | ".join(f"{k}: {fmt(v)}" for k,v in r.items()))
# dose-response
d["ff_t"] = pd.qcut(d.fastfood.rank(method="first"), 3, labels=["low","mid","high"]); d["fat_t"] = pd.qcut(d.fat_pct.rank(method="first"), 3, labels=["low","mid","high"])
print("\n=== Weighted prevalence by tertile (NAFLD % / elevated ALT %)")
for t in ["ff_t","fat_t"]:
    print(t, {k: (round(np.average(g.nafld,weights=g.w)*100,1), round(np.average(g.alt_high,weights=g.w)*100,1)) for k,g in d.groupby(t)})
# importance: cross-validated AUROC gain over covariates
Xb = d[base+["yearn"] if "yearn" in d else base].copy(); d["yearn"]=d.year-2008; basecols = base+["edu","incm","yearn"]
folds = list(GroupKFold(5).split(d, d.nafld, grp))
def cv(cols, y):
    X = d[cols].values.astype(float); oof=np.zeros(len(d))
    for tr,te in folds:
        m = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)).fit(X[tr], d[y].values[tr]); oof[te]=m.predict_proba(X[te])[:,1]
    return roc_auc_score(d[y], oof)
print("\n=== Out-of-fold AUROC (logistic, PSU-grouped 5-fold): covariates alone vs + each exposure")
for y,nm in [("nafld","NAFLD"),("alt_high","Elevated ALT")]:
    b = cv(basecols,y); print(f"{nm}: covariates {b:.3f} | +fat%E {cv(basecols+['fat_pct'],y):.3f} | +fast-food {cv(basecols+['fastfood'],y):.3f} | +both {cv(basecols+['fat_pct','fastfood'],y):.3f} | +both+energy {cv(basecols+['fat_pct','fastfood','N_EN'],y):.3f}")
