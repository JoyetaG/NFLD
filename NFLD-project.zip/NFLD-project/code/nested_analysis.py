import pickle, json, numpy as np, pandas as pd, warnings
from collections import Counter
warnings.filterwarnings("ignore")
from sklearn.metrics import roc_auc_score, brier_score_loss, roc_curve, matthews_corrcoef
d = pd.read_pickle("/home/claude/out/analytic.pkl").reset_index(drop=True); d["w"] = d.wt_tot / d.wt_tot.mean()
cache = pickle.load(open("/home/claude/out/nested_cache.pkl", "rb"))
y = d.nafld.values; n = len(d)
SETN = {"A": "A. Full (as originally specified)", "B": "B. HSI-free (drop BMI, ALT, AST, diabetes, sex)", "C": "C. HSI-free, also without waist & glucose", "D": "D. Diet + age/lifestyle only", "E": "E. Age/lifestyle only (no diet, no biomarkers)"}
MODN = {"LightGBM": "LightGBM", "XGBoost": "XGBoost", "Random Forest": "Random Forest", "MLP": "MLP", "Logistic Regression": "Logistic Regression", "KNN": "KNN", "Decision Tree": "Decision Tree", "Gaussian NB": "Gaussian NB"}
rng = np.random.default_rng(7); groups = pd.factorize(d.grp)[0]; ug = np.unique(groups); idx_by_g = {g: np.where(groups == g)[0] for g in ug}
boots = [np.concatenate([idx_by_g[g] for g in rng.choice(ug, len(ug), replace=True)]) for _ in range(200)]
rows, oof_store, best = [], {}, {}
for s in SETN:
    for m in MODN:
        ks = [k for k in cache if k[0] == s and k[1] == m]
        if len(ks) < 10: continue
        oof = np.full(n, np.nan); fold_auc = []
        for k in sorted(ks, key=lambda t: t[2]):
            c = cache[k]; oof[c["te"]] = c["p"]; fold_auc.append(roc_auc_score(y[c["te"]], c["p"]))
        assert not np.isnan(oof).any()
        ba = [roc_auc_score(y[b], oof[b]) for b in boots]
        rows.append(dict(feature_set=SETN[s], model=MODN[m], n_features=0, AUROC=roc_auc_score(y, oof), lo=np.percentile(ba, 2.5), hi=np.percentile(ba, 97.5),
                         AUROC_survey_weighted=roc_auc_score(y, oof, sample_weight=d.w), fold_sd=float(np.std(fold_auc)), Brier=brier_score_loss(y, oof)))
        oof_store[(SETN[s], MODN[m])] = oof
        best[(s, m)] = {p: Counter(str(cache[k]["params"][p]) for k in ks).most_common(1)[0][0] for p in cache[ks[0]]["params"]}
res = pd.DataFrame(rows); res.to_csv("/home/claude/out/ml_results.csv", index=False)
pickle.dump(dict(oof=oof_store, y=y, w=d.w.values), open("/home/claude/out/oof.pkl", "wb"))
json.dump({f"{k[0]}|{k[1]}": v for k, v in best.items()}, open("/home/claude/out/nested_best_params.json", "w"), indent=1)
piv = res.pivot(index="model", columns="feature_set", values="AUROC")
print(piv.round(3).to_string())
tot = sum(c["sec"] for c in cache.values()); print(f"\ncompute time in cache: {tot/60:.0f} min; entries {len(cache)}")
N = {}
top = lambda s, k=3: res[res.feature_set == SETN[s]].sort_values("AUROC", ascending=False).head(k)
for s in "ABCDE":
    t = top(s, 3); N[s] = dict(best=t.iloc[0].model, auc=float(t.iloc[0].AUROC), lo=float(t.iloc[0].lo), hi=float(t.iloc[0].hi), brier=float(res[res.feature_set == SETN[s]].sort_values("AUROC", ascending=False).iloc[0].Brier),
                                lgbm=float(res[(res.feature_set == SETN[s]) & (res.model == "LightGBM")].AUROC.iloc[0]), xgb=float(res[(res.feature_set == SETN[s]) & (res.model == "XGBoost")].AUROC.iloc[0]),
                                lr=float(res[(res.feature_set == SETN[s]) & (res.model == "Logistic Regression")].AUROC.iloc[0]), spread_top3=float(t.AUROC.max() - t.AUROC.min()), top3=list(t.model))
N["wdiff_max"] = float((res.AUROC_survey_weighted - res.AUROC).abs().max())
# Youden metrics for top 3 models in Set B
SB = SETN["B"]; met = {}
for m in top(SB[0], 3).model:
    p = oof_store[(SB, m)]; f, t, th = roc_curve(y, p); j = np.argmax(t - f); pr = (p >= th[j]).astype(int)
    tp = ((pr == 1) & (y == 1)).sum(); fp = ((pr == 1) & (y == 0)).sum(); fn = ((pr == 0) & (y == 1)).sum(); tn = ((pr == 0) & (y == 0)).sum()
    prec = tp / (tp + fp); sens = tp / (tp + fn); spec = tn / (tn + fp)
    met[m] = dict(sens=float(sens), spec=float(spec), f1=float(2 * prec * sens / (prec + sens)), mcc=float(matthews_corrcoef(y, pr)))
N["youden"] = met
print(json.dumps(N["youden"], indent=0)); print({s: (N[s]["best"], round(N[s]["auc"], 3), round(N[s]["lo"], 3), round(N[s]["hi"], 3)) for s in "ABCDE"}); print("top3 spread B", N["B"]["spread_top3"], "wdiff", N["wdiff_max"])
json.dump(N, open("/home/claude/out/nested_numbers.json", "w"), indent=1)
