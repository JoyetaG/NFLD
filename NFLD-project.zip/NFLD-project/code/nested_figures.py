import json, pickle, warnings, numpy as np, pandas as pd
warnings.filterwarnings("ignore")
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpecFromSubplotSpec
from matplotlib.patches import Patch
from sklearn.metrics import roc_curve, roc_auc_score, matthews_corrcoef
from sklearn.model_selection import GroupKFold
import shap, lightgbm as lgb
import ml_nested as M
NAVY, TEAL, RED, GOLD, GREY = "#1B3A6B", "#0E7C7B", "#C0392B", "#C8963E", "#888888"
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
O = "/mnt/user-data/outputs/"; d = M.d
res = pd.read_csv("/home/claude/out/ml_results.csv"); OO = pickle.load(open("/home/claude/out/oof.pkl", "rb")); y = OO["y"]
SB = [s for s in res.feature_set.unique() if s.startswith("B.")][0]; rb = res[res.feature_set == SB].sort_values("AUROC", ascending=False); mods = list(rb.model)
pal = dict(zip(mods, [NAVY, TEAL, GOLD, "#2980B9", "#8E44AD", "#1ABC9C", "#E74C3C", "#F39C12"]))
LOG = {}
# ======================= FIGURE 5: ML dashboard (Feature Set B, nested 10-fold OOF) =======================
fig, ax = plt.subplots(2, 3, figsize=(15, 9.2)); a = ax.ravel()
for i, m in enumerate(mods):
    f, t, _ = roc_curve(y, OO["oof"][(SB, m)]); a[0].plot(f, t, color=pal[m], lw=2.2 if i < 3 else 1.2, label=f"{m} ({rb.AUROC.iloc[i]:.3f})")
a[0].plot([0, 1], [0, 1], "--", color=GREY, lw=1); a[0].set_xlabel("1 – Specificity"); a[0].set_ylabel("Sensitivity"); a[0].legend(fontsize=7, frameon=False, loc="lower right")
a[0].set_title("A. ROC Curves — All 8 Models\n(Feature Set B, nested 10-fold CV)", fontweight="bold", color=NAVY)
lo_, hi_ = rb.AUROC.min() - 0.03, rb.AUROC.max() + 0.025
a[1].barh(range(len(mods))[::-1], rb.AUROC, color=[pal[m] for m in mods], xerr=[rb.AUROC - rb.lo, rb.hi - rb.AUROC], capsize=2); a[1].set_yticks(range(len(mods))[::-1]); a[1].set_yticklabels(mods); a[1].set_xlim(lo_, hi_)
for yy, v in zip(range(len(mods))[::-1], rb.AUROC): a[1].text(v + .006, yy, f"{v:.3f}", va="center", fontsize=8)
a[1].set_xlabel("AUROC"); a[1].set_title("B. AUROC Comparison\n(with 95% cluster-bootstrap CI)", fontweight="bold", color=NAVY)
sets = list(res.feature_set.unique()); wd = .38
for k, (m, col) in enumerate([("LightGBM", NAVY), ("Logistic Regression", GOLD)]):
    v = [res[(res.feature_set == s) & (res.model == m)].AUROC.iloc[0] for s in sets]; a[2].bar(np.arange(5) + (k - .5) * wd, v, wd, color=col, label=m)
    for xi, vv in zip(np.arange(5) + (k - .5) * wd, v): a[2].text(xi, vv + .01, f"{vv:.2f}", ha="center", fontsize=7)
a[2].set_xticks(range(5)); a[2].set_xticklabels([s.split(".")[0] for s in sets]); a[2].axhline(.5, color=GREY, ls=":"); a[2].set_ylim(.4, 1.08); a[2].set_ylabel("AUROC"); a[2].set_xlabel("Feature set (A full … E age/lifestyle only)"); a[2].legend(frameon=False, loc="upper right")
a[2].set_title("C. AUROC by Feature Set\n(leakage control)", fontweight="bold", color=NAVY)
for m in mods[:4]:
    p = OO["oof"][(SB, m)]; qq = pd.qcut(p, 10, duplicates="drop"); g = pd.DataFrame(dict(p=p, y=y, q=qq)).groupby("q").agg(pp=("p", "mean"), yy=("y", "mean")); a[3].plot(g.pp, g.yy, "o-", color=pal[m], label=m, ms=4)
a[3].plot([0, .7], [0, .7], "--", color=GREY); a[3].set_xlabel("Mean predicted probability"); a[3].set_ylabel("Observed fraction with NAFLD"); a[3].legend(frameon=False, fontsize=8); a[3].set_title("D. Calibration Curves (deciles)", fontweight="bold", color=NAVY)
br = rb.sort_values("Brier", ascending=False); a[4].barh(range(len(br)), br.Brier, color=[pal[m] for m in br.model]); a[4].set_yticks(range(len(br))); a[4].set_yticklabels(br.model)
for yy, v in zip(range(len(br)), br.Brier): a[4].text(v + .002, yy, f"{v:.3f}", va="center", fontsize=8)
ns = y.mean() * (1 - y.mean()); a[4].axvline(ns, color=GREY, ls="--", lw=1); a[4].set_xlabel("Brier score (↓ better; dashed = no-skill)"); a[4].set_title("E. Calibration — Brier Scores", fontweight="bold", color=NAVY)
top3 = mods[:3]; met = {}
for m in top3:
    p = OO["oof"][(SB, m)]; f, t, th = roc_curve(y, p); j = np.argmax(t - f); pr = (p >= th[j]).astype(int); tp_ = ((pr == 1) & (y == 1)).sum(); fp = ((pr == 1) & (y == 0)).sum(); fn = ((pr == 0) & (y == 1)).sum(); tn = ((pr == 0) & (y == 0)).sum()
    prec = tp_ / (tp_ + fp); sens = tp_ / (tp_ + fn); spec = tn / (tn + fp); met[m] = [roc_auc_score(y, p), sens, spec, 2 * prec * sens / (prec + sens), matthews_corrcoef(y, pr)]
names = ["AUROC", "Sensitivity", "Specificity", "F1", "MCC"]
for k, m in enumerate(top3): a[5].bar(np.arange(5) + (k - 1) * .27, met[m], .27, color=pal[m], label=m)
a[5].set_xticks(range(5)); a[5].set_xticklabels(names); a[5].set_ylim(.3, 1); a[5].set_ylabel("Score (Youden threshold)"); a[5].legend(frameon=False, fontsize=8); a[5].set_title("F. Top-3 Model Metric Comparison", fontweight="bold", color=NAVY)
plt.tight_layout(); plt.savefig(O + "Figure5_ML_Feature_Sets.png", dpi=170); plt.close()
# ======================= SHAP with tuned LightGBM (Set B, held-out PSU-grouped outer fold) =======================
bp = json.load(open("/home/claude/out/nested_best_params.json"))["B|LightGBM"]
cast = dict(n_estimators=int, learning_rate=float, num_leaves=int, min_child_samples=int, subsample=float, colsample_bytree=float, reg_lambda=float)
params = {k: cast[k](v) for k, v in bp.items()}; LOG["lgbm_params"] = params
featsB = M.SETS["B"]; y_all = d.nafld.values; groups = pd.factorize(d.grp)[0]
tr, te = next(iter(GroupKFold(10).split(d, y_all, groups)))
m = lgb.LGBMClassifier(**params, subsample_freq=1, verbose=-1, n_jobs=1, random_state=1).fit(d.loc[tr, featsB], y_all[tr])
Xt = d.loc[te, featsB].reset_index(drop=True)
nice = dict(HE_wc="Waist circumference", HE_glu="Fasting glucose", HE_TG="Triglycerides", HE_HDL="HDL-C", HE_chol="Total cholesterol", HE_sbp="SBP", HE_dbp="DBP", age="Age", smoker="Smoking", active="Physical activity", edu="Education", incm="Income", yearn="Survey year",
            N_EN="Energy", N_WATER="Water", N_PROT="Protein", N_FAT="Total fat", N_CHO="Carbohydrate", N_FIBER="Dietary fibre", N_ASH="Ash", N_CA="Calcium", N_PHOS="Phosphorus", N_FE="Iron", N_NA="Sodium", N_K="Potassium", N_VA="Vitamin A", N_CAROT="Carotene", N_RETIN="Retinol", N_B1="Thiamin", N_B2="Riboflavin", N_NIAC="Niacin", N_VITC="Vitamin C",
            prot_pct="Protein (% energy)", fat_pct="Fat (% energy)", cho_pct="Carbohydrate (% energy)", fiber_dens="Fibre density", na_dens="Sodium density", k_dens="Potassium density", na_k="Sodium:potassium ratio", tg_hdl="TG:HDL ratio", map="Mean arterial pressure")
sv = shap.TreeExplainer(m).shap_values(Xt); sv = sv[1] if isinstance(sv, list) else sv
Xn = Xt.rename(columns=nice); imp = pd.Series(np.abs(sv).mean(0), index=Xn.columns).sort_values(ascending=False)
dietn = [nice[c] for c in M.DIET + M.ENG_DIET]; metabn = [nice[c] for c in M.METAB + M.ENG_METAB]; lifen = [nice[c] for c in M.LIFE]
dom = {**{k: "Diet" for k in dietn}, **{k: "Metabolic/anthropometric" for k in metabn}, **{k: "Demographic/lifestyle" for k in lifen}}
share = pd.Series({k: imp[[c for c in imp.index if dom[c] == k]].sum() / imp.sum() for k in set(dom.values())})
imp.to_csv("/home/claude/out/shap_importance_setB.csv"); share.to_csv("/home/claude/out/shap_domain_share.csv")
LOG["shap_top"] = {k: round(float(v), 3) for k, v in imp.head(8).items()}; LOG["shap_share"] = {k: round(float(v) * 100, 1) for k, v in share.items()}; LOG["shap_n"] = int(len(te))
fig, ax = plt.subplots(1, 2, figsize=(15, 6.5), gridspec_kw=dict(width_ratios=[1.25, 1]))
plt.sca(ax[0]); shap.summary_plot(sv, Xn, max_display=15, show=False, plot_size=None, color_bar=True)
ax[0].set_title("A. SHAP beeswarm — LightGBM, HSI-free feature set\n(held-out PSU-grouped fold, top 15)", fontweight="bold", color=NAVY); ax[0].set_xlabel("SHAP value (impact on model output, log-odds)")
tp15 = imp.head(15)[::-1]; colr = [{"Diet": TEAL, "Metabolic/anthropometric": GOLD, "Demographic/lifestyle": NAVY}[dom[k]] for k in tp15.index]
ax[1].barh(tp15.index, tp15.values, color=colr); ax[1].set_title("B. Mean |SHAP|, top 15 features", fontweight="bold", color=NAVY); ax[1].set_xlabel("Mean |SHAP value|")
ax[1].legend(handles=[Patch(color=TEAL, label="Dietary"), Patch(color=GOLD, label="Metabolic / anthropometric"), Patch(color=NAVY, label="Demographic / lifestyle")], loc="lower right", frameon=False)
plt.tight_layout(); plt.savefig(O + "Figure6_SHAP_Importance.png", dpi=180); plt.close()
# ======================= FIGURE 7: dependence panels =======================
ci = lambda c: list(Xt.columns).index(c)
def dep(axx, c, colc, title, unit):
    x = Xt[c].values; lo, hi = np.percentile(x, [1, 99]); k = (x >= lo) & (x <= hi); s_ = sv[:, ci(c)]
    sc = axx.scatter(x[k], s_[k], c=Xt[colc].values[k], cmap="RdYlBu_r", s=8, alpha=.6); o = np.argsort(x[k]); ln = pd.Series(s_[k][o]).rolling(150, min_periods=30, center=True).mean()
    axx.plot(x[k][o], ln, color="k", lw=2); axx.axhline(0, color=GREY, ls="--", lw=1); axx.set_xlabel(f"{nice[c]} ({unit})"); axx.set_ylabel("SHAP value"); axx.set_title(title, fontweight="bold", color=NAVY)
    plt.colorbar(sc, ax=axx).set_label(nice[colc])
    q = pd.qcut(pd.Series(x), 5, labels=False, duplicates="drop"); LOG["dep_" + c] = [round(float(s_[q == i].mean()), 3) for i in range(5)]
fig, ax = plt.subplots(2, 3, figsize=(15, 9.4)); a = ax.ravel()
dep(a[0], "HE_wc", "age", "A. Waist Circumference → NAFLD\n(colour: age)", "cm"); dep(a[1], "N_FIBER", "N_EN", "B. Dietary Fibre → NAFLD\n(colour: energy intake)", "g/day")
dep(a[2], "N_K", "N_EN", "C. Potassium → NAFLD\n(colour: energy intake)", "mg/day"); dep(a[3], "N_NA", "N_EN", "D. Sodium → NAFLD\n(colour: energy intake)", "mg/day")
fb = np.percentile(d.N_FIBER, np.linspace(10, 90, 5)); sb = np.percentile(d.N_NA, np.linspace(10, 90, 5)); G = np.zeros((5, 5))
for i, sv_ in enumerate(sb):
    for j, fv in enumerate(fb):
        Xg = Xt.copy(); Xg["N_NA"] = sv_; Xg["N_FIBER"] = fv; G[i, j] = m.predict_proba(Xg)[:, 1].mean() * 100
im = a[4].imshow(G, origin="lower", cmap="YlOrRd", aspect="auto", vmin=10, vmax=35)
for i in range(5):
    for j in range(5): a[4].text(j, i, f"{G[i, j]:.1f}", ha="center", va="center", fontsize=8)
a[4].set_xticks(range(5)); a[4].set_xticklabels([f"{v:.1f}" for v in fb]); a[4].set_yticks(range(5)); a[4].set_yticklabels([f"{v:,.0f}" for v in sb]); a[4].set_xlabel("Dietary fibre (g/day)"); a[4].set_ylabel("Sodium (mg/day)")
plt.colorbar(im, ax=a[4], label="Mean predicted NAFLD probability (%)"); a[4].set_title("E. Interaction: Fibre × Sodium\n(2-D partial dependence)", fontweight="bold", color=NAVY); LOG["pdp_range"] = (round(float(G.min()), 1), round(float(G.max()), 1))
p_te = m.predict_proba(Xt)[:, 1]; hi_i, lo_i = int(np.argmax(p_te)), int(np.argmin(p_te)); a[5].axis("off"); sub = GridSpecFromSubplotSpec(2, 1, subplot_spec=a[5].get_subplotspec(), hspace=.55); LOG["force"] = {}
for k, (ii, ttl, col) in enumerate([(hi_i, "High-risk participant", RED), (lo_i, "Low-risk participant", TEAL)]):
    axx = fig.add_subplot(sub[k]); s_ = pd.Series(sv[ii], index=[nice.get(c, c) for c in Xt.columns]); topc = s_.reindex(s_.abs().sort_values(ascending=False).index[:6])[::-1]
    axx.barh(topc.index, topc.values, color=[RED if v > 0 else TEAL for v in topc.values]); axx.axvline(0, color="k", lw=.8); axx.set_title(f"{ttl}: predicted P(NAFLD) = {p_te[ii]:.2f}", fontsize=8.5, color=col, fontweight="bold"); axx.tick_params(labelsize=7.5)
    LOG["force"][ttl] = (round(float(p_te[ii]), 2), list(topc.index[::-1][:2]))
    if k == 1: axx.set_xlabel("SHAP contribution (log-odds)")
a[5].set_title("F. SHAP Force-Plot Summaries\n(2 representative test-fold participants)", fontweight="bold", color=NAVY, pad=30)
plt.tight_layout(); plt.savefig(O + "Figure7_SHAP_Dependence.png", dpi=170); plt.close()
LOG["metrics_top3"] = {mm: [round(float(v), 3) for v in met[mm]] for mm in top3}
json.dump(LOG, open("/home/claude/out/nested_fig_log.json", "w"), indent=1, default=float); print(json.dumps(LOG, indent=0, default=float)[:1500])
