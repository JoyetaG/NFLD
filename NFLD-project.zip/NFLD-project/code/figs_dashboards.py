"""Redraw the submitted multi-panel figures (2, 3, 5, 7) in the same layout using the real data."""
import pandas as pd, numpy as np, pickle, warnings, statsmodels.api as sm
warnings.filterwarnings("ignore")
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpecFromSubplotSpec
from matplotlib.patches import Patch
from scipy import stats
from sklearn.metrics import roc_curve, roc_auc_score, matthews_corrcoef, brier_score_loss
NAVY, TEAL, RED, GOLD, GREY = "#1B3A6B", "#0E7C7B", "#C0392B", "#C8963E", "#888888"
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
O = "/mnt/user-data/outputs/"
d = pd.read_pickle("/home/claude/out/analytic.pkl").reset_index(drop=True); d["w"] = d.wt_tot/d.wt_tot.mean(); d["yearn"]=d.year-2008
def ratio(y, w, h, c):
    y=np.asarray(y,float); w=np.asarray(w,float); p=(w*y).sum()/w.sum(); z=w*(y-p)/w.sum()
    cl=pd.DataFrame(dict(z=z,h=np.asarray(h),c=np.asarray(c))).groupby(["h","c"]).z.sum().reset_index(); v=0
    for _,g in cl.groupby("h"):
        n=len(g); v+= n/(n-1)*((g.z-g.z.mean())**2).sum() if n>1 else 0
    return p, np.sqrt(v)
wp = lambda m: ratio(d.nafld[m], d.w[m], d.kstrata[m], d.grp[m])
nd = lambda c: d[c]/d.N_EN*1000
nut = dict(N_FIBER="Dietary fibre", N_NA="Sodium", N_K="Potassium", N_CA="Calcium", N_VITC="Vitamin C", N_PROT="Protein", N_FAT="Total fat", N_CHO="Carbohydrate", N_FE="Iron", N_VA="Vitamin A")
for c in nut: d[c+"_nd"] = nd(c)
d["ag"] = pd.cut(d.age, [19,29,39,49,59,69,120], labels=["20–29","30–39","40–49","50–59","60–69","70+"])
log = {}
# =============== FIGURE 2 (six panels, as submitted) ===============
fig, ax = plt.subplots(2, 3, figsize=(15, 9.2)); a = ax.ravel()
labs = list(d.ag.cat.categories); x = np.arange(6); bw = .38
for k,(sx,nm,col) in enumerate([(1,"Male",NAVY),(2,"Female",TEAL)]):
    ps=[];es=[]
    for g in labs: p,s=wp((d.sex==sx)&(d.ag==g)); ps.append(p*100); es.append(1.96*s*100)
    a[0].bar(x+(k-.5)*bw, ps, bw, yerr=es, color=col, capsize=2, label=nm)
    for xi,p,e in zip(x+(k-.5)*bw,ps,es): a[0].text(xi,p+e+.5,f"{p:.0f}",ha="center",fontsize=7.5)
a[0].set_xticks(x); a[0].set_xticklabels(labs); a[0].set_ylabel("NAFLD prevalence (%), survey-weighted"); a[0].legend(frameon=False); a[0].set_title("A. NAFLD Prevalence\nby Age Group and Sex", fontweight="bold", color=NAVY)
bins = np.linspace(14, 40, 53)
for v,col,nm in [(0,TEAL,"Non-NAFLD"),(1,RED,"NAFLD")]:
    a[1].hist(d.HE_BMI[d.nafld==v], bins=bins, density=True, alpha=.6, color=col, label=nm)
a[1].axvline(25, color="k", ls="--", lw=1.2, label="BMI=25"); a[1].axvline(30, color=GOLD, ls=":", lw=1.6, label="BMI=30"); a[1].set_xlabel("BMI (kg/m²)"); a[1].set_ylabel("Density"); a[1].legend(frameon=False, fontsize=8)
a[1].set_title("B. BMI Distribution\nNAFLD vs. Non-NAFLD", fontweight="bold", color=NAVY)
q = 4; w_ = .38; tp = {}
for k,(c,col,nm) in enumerate([("N_FIBER_nd",TEAL,"Fibre density"),("N_NA_nd",RED,"Sodium density")]):
    qq = pd.qcut(d[c], q, labels=False); ps=[];es=[]
    for j in range(q): p,s=wp(qq==j); ps.append(p*100); es.append(1.96*s*100)
    X = sm.add_constant(pd.DataFrame(dict(q=qq.astype(float), age=d.age, f=d.female)))
    m = sm.GLM(d.nafld, X, family=sm.families.Binomial(), freq_weights=d.w).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(d.grp)[0]}); tp[nm]=(m.pvalues["q"], np.exp(m.params["q"]))
    a[2].bar(np.arange(q)+(k-.5)*w_, ps, w_, yerr=es, color=col, capsize=2, label=nm); log["quart_"+nm]=[round(v,1) for v in ps]
a[2].set_ylim(0,31); a[2].set_xticks(range(q)); a[2].set_xticklabels(["Q1\n(Lowest)","Q2","Q3","Q4\n(Highest)"]); a[2].set_ylabel("NAFLD prevalence (%), survey-weighted"); a[2].legend(frameon=False, loc="upper left", fontsize=8)
a[2].text(0.98, 0.97, "\n".join(f"p-trend {k.split()[0]}: {v[0]:.3f}" for k,v in tp.items()), transform=a[2].transAxes, ha="right", va="top", fontsize=8, color=NAVY)
a[2].set_title("C. NAFLD Prevalence by Quartile of\nNutrient Density (per 1,000 kcal)", fontweight="bold", color=NAVY); log["ptrend"]={k:(round(v[0],3),round(v[1],3)) for k,v in tp.items()}
mk = [("HE_alt","ALT\n(IU/L)"),("HE_ast","AST\n(IU/L)"),("HE_TG","Triglycerides\n(mg/dL)")]
for i,(c,l) in enumerate(mk):
    for k,(v,col) in enumerate([(1,RED),(0,TEAL)]):
        s = d[c][d.nafld==v]; med=s.median(); lo,hi = s.quantile([.25,.75])
        a[3].bar(i+(k-.5)*.38, med, .38, color=col, label=("NAFLD" if v else "Non-NAFLD") if i==0 else None); a[3].errorbar(i+(k-.5)*.38, med, yerr=[[med-lo],[hi-med]], color="k", capsize=3, lw=1)
    p = stats.mannwhitneyu(d[c][d.nafld==1], d[c][d.nafld==0]).pvalue; a[3].text(i, d[c][d.nafld==1].quantile(.75)+6, "***" if p<.001 else f"p={p:.3f}", ha="center")
a[3].set_ylim(0,245); a[3].set_xticks(range(3)); a[3].set_xticklabels([l for _,l in mk]); a[3].set_ylabel("Median value"); a[3].legend(frameon=False, loc="upper left"); a[3].set_title("D. Biochemical Markers\nNAFLD vs. Non-NAFLD (median, IQR)", fontweight="bold", color=NAVY)
cols = ["N_FIBER","N_K","N_CA","N_VITC","N_PROT","N_FAT","N_NA"]; grp = [("NAFLD\nMen",(d.nafld==1)&(d.sex==1)),("NAFLD\nWomen",(d.nafld==1)&(d.sex==2)),("Non-NAFLD\nMen",(d.nafld==0)&(d.sex==1)),("Non-NAFLD\nWomen",(d.nafld==0)&(d.sex==2))]
Z = np.array([[((d[c+"_nd"]-d[c+"_nd"].mean())/d[c+"_nd"].std())[m].mean() for c in cols] for _,m in grp])
im = a[4].imshow(Z, cmap="RdBu_r", vmin=-.6, vmax=.6, aspect="auto")
for i in range(4):
    for j in range(len(cols)): a[4].text(j, i, f"{Z[i,j]:+.2f}", ha="center", va="center", fontsize=8)
a[4].set_xticks(range(len(cols))); a[4].set_xticklabels([nut[c] for c in cols], rotation=35, ha="right"); a[4].set_yticks(range(4)); a[4].set_yticklabels([g for g,_ in grp])
a[4].spines[:].set_visible(False); plt.colorbar(im, ax=a[4], label="Mean z-score of nutrient density"); a[4].set_title("E. Nutrient Density (z-score)\nby NAFLD Status and Sex", fontweight="bold", color=NAVY); log["heat"]=Z.round(2).tolist()
yrs=[2008,2009,2010,2011]; ps=[];es=[]
for y_ in yrs: p,s=wp(d.year==y_); ps.append(p*100); es.append(1.96*s*100)
a[5].errorbar(yrs, ps, yerr=es, color=RED, marker="o", lw=2, capsize=3); 
for y_,p in zip(yrs,ps): a[5].text(y_, p+es[yrs.index(y_)]+.4, f"{p:.1f}%", ha="center", fontsize=8, color=RED)
a[5].set_xticks(yrs); a[5].set_ylim(15, 29); a[5].set_ylabel("NAFLD prevalence (%), survey-weighted"); a[5].set_title("F. Temporal Trend: NAFLD\nPrevalence by Survey Year (2008–2011)", fontweight="bold", color=NAVY); log["year"]=[round(v,1) for v in ps]
plt.tight_layout(); plt.savefig(O+"Figure2_Prevalence_by_Age_Sex.png", dpi=170); plt.close()
# =============== FIGURE 3 (radar + forest, as submitted) ===============
import re
reg = pd.read_csv("/home/claude/out/table_regression.csv")
def parse(s): m=re.match(r"([\d.]+) \(([\d.]+)–([\d.]+)\)", s); return tuple(map(float,m.groups()))
order=["Dietary fibre","Sodium","Potassium","Vitamin C","Calcium","Total fat","Carbohydrate","Protein","Water","Energy"]
r=reg.set_index("Nutrient").loc[order]; c3=[c for c in reg.columns if c.startswith("Model 3 (+ total")][0]; cb=[c for c in reg.columns if "+ BMI" in c and not c.endswith(" p")][0]
fig = plt.figure(figsize=(15, 6.4)); axr = fig.add_subplot(1,2,1, projection="polar"); axf = fig.add_subplot(1,2,2)
rc = ["N_FIBER","N_NA","N_K","N_CA","N_VITC","N_PROT","N_FAT","N_CHO","N_FE","N_VA"]; ang = np.linspace(0, 2*np.pi, len(rc), endpoint=False); ang2 = np.r_[ang, ang[0]]
for v,col,nm in [(1,RED,f"NAFLD (n={int(d.nafld.sum()):,})"),(0,TEAL,f"Non-NAFLD (n={int((1-d.nafld).sum()):,})")]:
    vals = [d[c+"_nd"].rank(pct=True)[d.nafld==v].mean()*100 for c in rc]; axr.plot(ang2, vals+[vals[0]], color=col, lw=2.2, marker="o", label=nm); axr.fill(ang2, vals+[vals[0]], color=col, alpha=.15)
axr.set_xticks(ang); axr.set_xticklabels([nut[c] for c in rc], fontsize=9, color=NAVY, fontweight="bold"); axr.set_ylim(40, 60); axr.set_yticks([45,50,55]); axr.set_yticklabels(["45","50","55"], fontsize=7)
axr.legend(loc="upper center", bbox_to_anchor=(0.5, -0.06), ncol=2, frameon=False); axr.set_title("A. Nutritional Profile\n(energy-adjusted intake percentile; 50 = median)", fontweight="bold", color=NAVY, pad=26)
ypos = np.arange(10)[::-1]
for yy,(nm,row) in zip(ypos, r.iterrows()):
    o,l,h=parse(row[c3]); axf.plot([l,h],[yy+.12]*2,color=TEAL,lw=2); axf.plot(o,yy+.12,"D",color=TEAL,ms=6)
    o2,l2,h2=parse(row[cb]); axf.plot([l2,h2],[yy-.12]*2,color=GOLD,lw=2); axf.plot(o2,yy-.12,"s",color=GOLD,ms=5)
axf.axvline(1,color="k",ls="--",lw=1); axf.set_yticks(ypos); axf.set_yticklabels([f"{n} ({r.loc[n,'Increment']})" for n in order], fontsize=8.5); axf.set_xlim(0.9,1.16)
axf.set_xlabel("Adjusted odds ratio (95% CI) for NAFLD"); axf.legend(handles=[Patch(color=TEAL,label="Model 3 (age, sex, smoking, activity, education, income, energy)"),Patch(color=GOLD,label="Model 3 + BMI (over-adjusted; BMI is part of HSI)")], frameon=False, fontsize=8, loc="upper center", bbox_to_anchor=(0.4,-0.12))
axf.set_title("B. Multivariable-Adjusted Nutritional\nAssociations with NAFLD", fontweight="bold", color=NAVY)
plt.tight_layout(); plt.savefig(O+"Figure3_Adjusted_Associations.png", dpi=170, bbox_inches="tight"); plt.close()
print('Figures 2 and 3 done')
