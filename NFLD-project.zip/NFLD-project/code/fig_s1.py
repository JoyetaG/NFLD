import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
NAVY, TEAL, RED, GOLD = "#1B3A6B", "#0E7C7B", "#C0392B", "#C8963E"
fig, ax = plt.subplots(figsize=(11, 11)); ax.axis("off"); ax.set_xlim(0, 11); ax.set_ylim(0, 11.4)
def box(x, y, w, h, text, fc, ec, fs=9.5, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12", fc=fc, ec=ec, lw=1.6))
    ax.text(x+w/2, y+h/2, text, ha="center", va="center", fontsize=fs, color=NAVY, fontweight="bold" if bold else "normal", linespacing=1.3)
def arr(x1, y1, x2, y2): ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="->", color=NAVY, lw=1.5))
box(1.5, 10.2, 8, 0.9, "Supplied KNHANES 2008–2011 file\n39,306 data lines; 39,288 readable rows", "#E6EEF8", NAVY, bold=True); arr(5.5, 10.2, 5.5, 9.7)
box(1.0, 8.8, 9, 0.9, "Remove duplicated records (all 2010 and 2011 records appeared twice)\n→ 26,684 unique participants", "#E6EEF8", NAVY); arr(5.5, 8.8, 5.5, 8.3)
box(0.5, 7.2, 10, 1.1, "Sequential exclusions: missing HSI inputs, missing 24-h recall, HBsAg-positive, heavy-alcohol flag,\npregnancy, implausible energy intake, missing covariates  →  analytic sample n = 18,506\nNAFLD = HSI > 36 (n = 3,877)", "#E0F0EF", TEAL, fs=9)
xs = [0.2, 2.9, 5.6, 8.3]; W = 2.5
for x in xs: arr(5.5, 7.2, x+W/2, 6.55)
box(xs[0], 2.2, W, 4.3, "Survey-weighted regression\n\nModels 1–3\n(+ BMI sensitivity)\n\nwt_tot weights,\nPSU-clustered SEs\n\nTable 4, Figure 3", "#FFF6E5", GOLD, fs=9)
box(xs[1], 2.2, W, 4.3, "Machine learning\n\nFeature engineering and\npreprocessing fitted\nwithin training folds\n\nFeature sets A–E;\n8 classifiers\n\nNested CV: outer 10-fold\ngrouped by PSU; inner 3-fold\nhyperparameter tuning\n\nOOF AUROC (cluster\nbootstrap CI), Brier\n\nTable 3, Figure 5", "#E6EEF8", NAVY, fs=8.3)
box(xs[2], 2.2, W, 4.3, "SHAP explainability\n\nLightGBM on Set B\n(HSI components removed)\n\nHeld-out PSU-grouped fold\n\nFigures 6 and 7", "#FDECEA", RED, fs=9)
box(xs[3], 2.2, W, 4.3, "Dietary score (NLRS)\n\nLASSO on 18 nutrient\ndensities\n\nDerive 2008–2009,\nvalidate 2010–2011\n\nTable 2, Figure 4", "#E0F0EF", TEAL, fs=9)
ax.text(5.5, 1.3, "Outputs: Tables 1–4, Figures 1–7. All steps use one record per participant.", ha="center", fontsize=9.5, color=NAVY, style="italic")
ax.set_title("Supplementary Figure S1. Analysis pipeline of the revised study", fontweight="bold", color=NAVY, fontsize=12)
plt.savefig("/mnt/user-data/outputs/SupplementaryFigureS1_Analysis_Pipeline.png", dpi=170, bbox_inches="tight")
