import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
NAVY, RED, GOLD, GREY = "#1B3A6B", "#C0392B", "#C8963E", "#888888"
fig, ax = plt.subplots(figsize=(13, 6.8)); ax.axis("off"); ax.set_xlim(0, 13.2); ax.set_ylim(0.6, 7.2)
nodes = {}
def box(key, x, y, w, h, text, fc, ec, ls="-", fs=9.4):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.03,rounding_size=0.14", fc=fc, ec=ec, lw=1.7, ls=ls)); ax.text(x + w/2, y + h/2, text, ha="center", va="center", fontsize=fs, color=NAVY, linespacing=1.3); nodes[key] = (x, y, w, h)
def pt(key, side):
    x, y, w, h = nodes[key]; return {"l": (x, y + h/2), "r": (x + w, y + h/2), "t": (x + w/2, y + h), "b": (x + w/2, y)}[side]
def arrow(a, sa, b, sb, dashed=False, color=NAVY, rad=0.0):
    ax.annotate("", xy=pt(b, sb), xytext=pt(a, sa), arrowprops=dict(arrowstyle="-|>", color=color, lw=1.7, ls="--" if dashed else "-", connectionstyle=f"arc3,rad={rad}", shrinkA=2, shrinkB=2))
OBS, LAT, OUT = "#E6EEF8", "#EFEFEF", "#FFF2D9"
box("conf", 0.2, 3.3, 2.6, 2.2, "Confounders\n\nAge, sex\nEducation, income\nSmoking, survey year", OBS, NAVY)
box("diet", 3.9, 5.1, 3.0, 1.6, "Diet and behaviours\n\n24-h recall, soda, fast food,\nphysical inactivity\n(measured with error)", OBS, NAVY)
box("adip", 7.9, 4.5, 2.2, 1.3, "Adiposity\n(BMI, waist)", OBS, NAVY)
box("liver", 7.9, 1.5, 2.2, 1.3, "Hepatic fat (NAFLD)\nnot measured", LAT, GREY, ls="--")
box("alt", 10.9, 1.5, 2.1, 1.3, "ALT, AST\nmeasured", OBS, NAVY)
box("hsi", 10.6, 4.4, 2.5, 1.7, "HSI (outcome used)\n8×ALT/AST + BMI\n+ diabetes + sex", OUT, GOLD)
arrow("conf", "r", "diet", "l"); arrow("conf", "b", "liver", "l", rad=0.25)
arrow("diet", "r", "adip", "l"); arrow("adip", "b", "liver", "t")
arrow("diet", "b", "liver", "l", rad=0.12)
arrow("liver", "l", "diet", "b", dashed=True, color=RED, rad=-0.55)
arrow("liver", "r", "alt", "l"); arrow("alt", "t", "hsi", "b"); arrow("adip", "r", "hsi", "l")
ax.text(6.6, 0.95, "Solid arrows: assumed causal effects.   Dashed red: reverse causation (NAFLD changes diet and activity).\nBlue boxes are measured; the grey dashed box is not; the gold box is the outcome used in the analysis.   Energy under-reporting depends on body size.", ha="center", fontsize=8.8, color=NAVY, style="italic")
plt.savefig("/mnt/user-data/outputs/Figure9_Causal_Diagram.png", dpi=170, bbox_inches="tight")
