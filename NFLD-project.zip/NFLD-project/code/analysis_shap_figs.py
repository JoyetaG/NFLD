import pandas as pd, numpy as np, pickle, warnings, shap, lightgbm as lgb
warnings.filterwarnings("ignore")
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_curve, roc_auc_score
NAVY, TEAL, RED, GOLD = "#1B3A6B", "#0E7C7B", "#C0392B", "#C8963E"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
d = pd.read_pickle("/home/claude/out/analytic.pkl").reset_index(drop=True); d["yearn"]=d.year-2008
diet = ['N_EN','N_WATER','N_PROT','N_FAT','N_CHO','N_FIBER','N_ASH','N_CA','N_PHOS','N_FE','N_NA','N_K','N_VA','N_CAROT','N_RETIN','N_B1','N_B2','N_NIAC','N_VITC']
life = ['age','smoker','active','edu','incm','yearn']; metab = ['HE_wc','HE_glu','HE_TG','HE_HDL','HE_chol','HE_sbp','HE_dbp']
featsB = life + metab + diet
nice = dict(HE_wc="Waist circumference",HE_glu="Fasting glucose",HE_TG="Triglycerides",HE_HDL="HDL-C",HE_chol="Total cholesterol",HE_sbp="SBP",HE_dbp="DBP",age="Age",smoker="Smoking",active="Physical activity",edu="Education",incm="Income",yearn="Survey year",
 N_EN="Energy",N_WATER="Water",N_PROT="Protein",N_FAT="Total fat",N_CHO="Carbohydrate",N_FIBER="Dietary fibre",N_ASH="Ash",N_CA="Calcium",N_PHOS="Phosphorus",N_FE="Iron",N_NA="Sodium",N_K="Potassium",N_VA="Vitamin A",N_CAROT="Carotene",N_RETIN="Retinol",N_B1="Thiamin",N_B2="Riboflavin",N_NIAC="Niacin",N_VITC="Vitamin C")
# ---------- SHAP, LightGBM, feature set B, held-out PSU-grouped fold ----------
y = d.nafld.values; groups = pd.factorize(d.grp)[0]
tr, te = next(iter(GroupKFold(5).split(d, y, groups)))
m = lgb.LGBMClassifier(n_estimators=300, learning_rate=0.05, num_leaves=15, subsample=0.8, subsample_freq=1, colsample_bytree=0.8, verbose=-1, n_jobs=1, random_state=1).fit(d.loc[tr, featsB], y[tr])
Xte = d.loc[te, featsB].rename(columns=nice)
sv = shap.TreeExplainer(m).shap_values(Xte); sv = sv[1] if isinstance(sv, list) else sv
imp = pd.Series(np.abs(sv).mean(0), index=Xte.columns).sort_values(ascending=False)
dom = {**{nice[c]:"Diet" for c in diet}, **{nice[c]:"Metabolic/anthropometric" for c in metab}, **{nice[c]:"Demographic/lifestyle" for c in life}}
share = pd.Series({k: imp[[c for c in imp.index if dom[c]==k]].sum()/imp.sum() for k in set(dom.values())})
print("Test-fold n =", len(te)); print(imp.head(12).round(3).to_string()); print("\nShare of total mean|SHAP| by domain:\n", (share*100).round(1).to_string())
imp.to_csv("/home/claude/out/shap_importance_setB.csv"); share.to_csv("/home/claude/out/shap_domain_share.csv")
fig, ax = plt.subplots(1, 2, figsize=(15, 6.5), gridspec_kw=dict(width_ratios=[1.25, 1]))
plt.sca(ax[0]); shap.summary_plot(sv, Xte, max_display=15, show=False, plot_size=None, color_bar=True)
ax[0].set_title("A. SHAP beeswarm — LightGBM, HSI-free feature set\n(held-out PSU-grouped fold, top 15)", fontweight="bold", color=NAVY); ax[0].set_xlabel("SHAP value (impact on model output, log-odds)")
top = imp.head(15)[::-1]; colr = [{"Diet":TEAL,"Metabolic/anthropometric":GOLD,"Demographic/lifestyle":NAVY}[dom[k]] for k in top.index]
ax[1].barh(top.index, top.values, color=colr); ax[1].set_title("B. Mean |SHAP|, top 15 features", fontweight="bold", color=NAVY); ax[1].set_xlabel("Mean |SHAP value|")
from matplotlib.patches import Patch
ax[1].legend(handles=[Patch(color=TEAL,label="Dietary"),Patch(color=GOLD,label="Metabolic / anthropometric"),Patch(color=NAVY,label="Demographic / lifestyle")], loc="lower right", frameon=False)
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/Fig4_SHAP_HSI_free.png", dpi=180); plt.close()
fig, ax = plt.subplots(1, 3, figsize=(14, 4))
for a, c in zip(ax, ["Dietary fibre","Sodium","Potassium"]):
    x = Xte[c].values; lo, hi = np.percentile(x, [1, 99]); k = (x>=lo)&(x<=hi)
    a.scatter(x[k], sv[k, list(Xte.columns).index(c)], s=6, alpha=.35, color=TEAL); 
    o = np.argsort(x[k]); s = pd.Series(sv[k, list(Xte.columns).index(c)][o]).rolling(150, min_periods=30, center=True).mean()
    a.plot(x[k][o], s, color=RED, lw=2); a.axhline(0, color="grey", ls="--", lw=1); a.set_xlabel(c + (" (g/day)" if c=="Dietary fibre" else " (mg/day)")); a.set_ylabel("SHAP value"); a.set_title(c, fontweight="bold", color=NAVY)
plt.suptitle("SHAP dependence for selected dietary variables (HSI-free LightGBM, held-out fold)", y=1.02, fontweight="bold", color=NAVY)
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/Fig5_SHAP_dependence.png", dpi=180, bbox_inches="tight"); plt.close()

# ---------- ROC by feature set (correct orientation) ----------
res = pd.read_csv("/home/claude/out/ml_results.csv"); O = pickle.load(open("/home/claude/out/oof.pkl","rb"))
sets = list(dict.fromkeys(res.feature_set)); cols = [RED, GOLD, TEAL, NAVY, "#888888"]
fig, ax = plt.subplots(1, 2, figsize=(13, 5.2))
for s, c in zip(sets, cols):
    best = res[res.feature_set==s].sort_values("AUROC").iloc[-1]; fpr, tpr, _ = roc_curve(O["y"], O["oof"][(s, best.model)])
    ax[0].plot(fpr, tpr, color=c, lw=2, label=f"{s.split('. ')[0]}. {s.split('. ')[1][:38]} — {best.model} ({best.AUROC:.3f})")
ax[0].plot([0,1],[0,1], color="grey", ls="--", lw=1); ax[0].set_xlabel("1 – Specificity"); ax[0].set_ylabel("Sensitivity"); ax[0].legend(fontsize=7.5, loc="lower right", frameon=False)
ax[0].set_title("A. Out-of-fold ROC, best model per feature set\n(5-fold, PSU-grouped)", fontweight="bold", color=NAVY)
lgbr = res[res.model=="LightGBM"].set_index("feature_set").loc[sets]
ax[1].bar(range(5), lgbr.AUROC, yerr=[lgbr.AUROC-lgbr.lo, lgbr.hi-lgbr.AUROC], color=cols, capsize=3); ax[1].set_xticks(range(5)); ax[1].set_xticklabels([s.split(".")[0] for s in sets])
for i, v in enumerate(lgbr.AUROC): ax[1].text(i, v+0.02, f"{v:.3f}", ha="center", fontsize=9)
ax[1].axhline(0.5, color="grey", ls=":"); ax[1].set_ylim(0.4, 1.05); ax[1].set_ylabel("AUROC (LightGBM)")
ax[1].set_title("B. AUROC collapses once HSI inputs are removed;\ndiet adds nothing beyond age/lifestyle (D vs E)", fontweight="bold", color=NAVY)
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/Fig3_ROC_feature_sets.png", dpi=180); plt.close()

# ---------- NLRS validation figure ----------
R = pickle.load(open("/home/claude/out/nlrs.pkl","rb"))["temporal"]
fig, ax = plt.subplots(1, 3, figsize=(15, 4.8))
fpr, tpr, _ = roc_curve(R["y_val"], R["score_val"]); ax[0].plot(fpr, tpr, color=TEAL, lw=2, label=f"NLRS (AUROC={R['auc']:.3f})"); ax[0].plot([0,1],[0,1],"--",color="grey", lw=1)
ax[0].set_xlabel("1 – Specificity"); ax[0].set_ylabel("Sensitivity"); ax[0].legend(frameon=False, loc="lower right"); ax[0].set_title("A. NLRS ROC — temporal validation\n(derive 2008–09, test 2010–11)", fontweight="bold", color=NAVY)
cal = R["cal"]; ax[1].plot([0,0.5],[0,0.5],"--",color="grey"); ax[1].plot(cal.pred, cal.obs, "o-", color=TEAL); ax[1].set_xlabel("Predicted probability"); ax[1].set_ylabel("Observed proportion")
ax[1].set_title(f"B. Calibration (covariates + NLRS)\nH-L χ²={R['hl'][0]:.1f}, p={R['hl'][1]:.3f}", fontweight="bold", color=NAVY)
q = np.array(R["qor"]); ax[2].bar(range(1,6), q[:,0], color=[TEAL]*5, yerr=[q[:,0]-q[:,1], q[:,2]-q[:,0]], capsize=3); ax[2].axhline(1, color=RED, ls="--"); ax[2].set_xticks(range(1,6)); ax[2].set_xticklabels([f"Q{i}" for i in range(1,6)])
ax[2].set_ylabel("Adjusted OR (age, sex, smoking, activity)"); ax[2].set_title(f"C. NLRS quintile aORs (Q1 = ref)\np-trend = {R['ptrend']:.3f}", fontweight="bold", color=NAVY)
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/Fig6_NLRS_validation.png", dpi=180); plt.close()

# ---------- corrected flow diagram ----------
fl = pd.read_csv("/home/claude/out/flow.csv")
fig, ax = plt.subplots(figsize=(11, 10)); ax.axis("off"); ax.set_xlim(0, 11); ax.set_ylim(0, 10.6)
steps = fl.iloc[1:].reset_index(drop=True); n = len(steps); y0 = 10.0; dy = 0.92
short = ["Readable rows in supplied file", "After removing duplicate records\n(2010 and 2011 records were duplicated)", "After excluding age < 19 y", "After excluding missing HSI inputs\n(ALT, AST, BMI, diabetes)", "After excluding missing 24-h recall", "After excluding HBsAg-positive", "After excluding heavy-alcohol flag", "After excluding pregnancy", "After excluding implausible energy intake", "Final analytic sample\n(after missing-covariate exclusion)"]
for i, r in steps.iterrows():
    yy = y0 - i*dy; fin = i == n-1
    ax.add_patch(plt.Rectangle((0.6, yy-0.36), 5.6, 0.72, fc="#E0F0EF" if fin else "#E6EEF8", ec=TEAL if fin else NAVY, lw=1.6))
    ax.text(3.4, yy+0.12, short[i], ha="center", va="center", fontsize=9, fontweight="bold", color=NAVY); ax.text(3.4, yy-0.2, f"n = {int(r.remaining):,}", ha="center", va="center", fontsize=9, style="italic", color=NAVY)
    if i>0 and r.excluded>0 or (i==1):
        ax.add_patch(plt.Rectangle((6.9, yy-0.3), 3.8, 0.6, fc="#FDECEA", ec=RED, lw=1.2)); ax.text(8.8, yy, f"Excluded n = {int(r.excluded):,}", ha="center", va="center", fontsize=9, color=RED)
        ax.annotate("", xy=(6.2, yy), xytext=(6.9, yy), arrowprops=dict(arrowstyle="->", color=RED))
    if i < n-1: ax.annotate("", xy=(3.4, yy-dy+0.36), xytext=(3.4, yy-0.36), arrowprops=dict(arrowstyle="->", color=NAVY))
ax.text(3.4, y0-n*dy+0.35, f"NAFLD (HSI > 36): n = {int(d.nafld.sum()):,} ({d.nafld.mean()*100:.1f}% unweighted; 22.2% survey-weighted)\nNon-NAFLD: n = {int((1-d.nafld).sum()):,}", ha="center", fontsize=9.5, color=RED, fontweight="bold")
ax.set_title("Figure 1. Participant flow — KNHANES 2008–2011 (rebuilt from supplied data)", fontweight="bold", color=NAVY, fontsize=12)
plt.savefig("/mnt/user-data/outputs/Fig1_participant_flow.png", dpi=170, bbox_inches="tight"); plt.close()
print("figures done")
