"""Step 1: rebuild the NAFLD analytic cohort from the supplied KNHANES 2008-2011 file.
- de-duplicates participants (every 2010/2011 record appears twice in the supplied file)
- applies the exclusion criteria stated in the manuscript, sequentially
- NAFLD = Hepatic Steatosis Index > 36 (file's HSI, which reproduces from ALT/AST/BMI/sex/diabetes)
"""
import pandas as pd, numpy as np, json, csv

RAW = "/mnt/user-data/uploads/UTI_Data__1_.csv"
# lines with an extra field (18 lines / 14 IDs) cannot be parsed reliably -> dropped and reported
raw = pd.read_csv(RAW, encoding="latin1", low_memory=False, on_bad_lines="skip", na_values=["NA", ""])
n_rows_parsed = len(raw)
bad_ids = set()
with open(RAW, encoding="latin1", newline="") as f:
    r = csv.reader(f); hdr = next(r)
    for row in r:
        if len(row) != len(hdr): bad_ids.add(row[0])
n_lines_total = n_rows_parsed + 18

raw["_nn"] = raw.notna().sum(axis=1)
u = (raw.sort_values(["ID", "_nn"], ascending=[True, False])
        .drop_duplicates("ID").drop(columns="_nn").reset_index(drop=True))

flow = []
def step(label, mask_keep, d):
    n0 = len(d); d2 = d[mask_keep].copy()
    flow.append(dict(step=label, excluded=n0 - len(d2), remaining=len(d2)))
    return d2

flow.append(dict(step="Rows in supplied file (data lines)", excluded=None, remaining=n_lines_total))
flow.append(dict(step="Rows readable by parser", excluded=n_lines_total-n_rows_parsed, remaining=n_rows_parsed))
flow.append(dict(step="Duplicate records of the same participant ID removed (all 2010 and 2011 records were duplicated)",
                 excluded=n_rows_parsed-len(u), remaining=len(u)))
d = u.copy()
d = step("Age < 19 years", d.age >= 19, d)
d["diab"] = (d.HE_DMdg == 1).astype(float); d.loc[d.HE_DMdg.isna(), "diab"] = np.nan
d = step("Missing HSI inputs (ALT, AST, BMI or diabetes status)", d[["HE_alt","HE_ast","HE_BMI","diab","HSI"]].notna().all(axis=1), d)
d = step("Missing 24-h dietary recall", d.N_EN.notna(), d)
d = step("HBsAg positive", ~(d.HE_hepaB == 1) & d.HE_hepaB.notna(), d)
d = step("Heavy-alcohol flag (HE_ALC = 1)", ~(d.HE_ALC == 1) & d.HE_ALC.notna(), d)
d = step("Pregnant", ~(d.HE_prg == 1), d)
d = step("Implausible energy intake (<500 or >5,000 kcal/day)", d.N_EN.between(500, 5000), d)
need = ["sm_presnt","pa_high","pa_mid","pa_walk","edu","incm","wt_tot","psu","kstrata","HE_wc","HE_glu","HE_TG","HE_HDL","HE_chol","HE_sbp","HE_dbp"]
d = step("Missing covariates / design variables (smoking, activity, education, income, survey weight, waist, glucose, lipids, BP)", d[need].notna().all(axis=1), d)

d["nafld"] = (d.HSI > 36).astype(int)
d["active"] = ((d.pa_high == 1) | (d.pa_mid == 1) | (d.pa_walk == 1)).astype(int)
d["female"] = (d.sex == 2).astype(int)
d["smoker"] = d.sm_presnt.astype(int)
d["grp"] = d.psu.astype(str)
d.to_pickle("/home/claude/out/analytic.pkl")
fl = pd.DataFrame(flow); fl.to_csv("/home/claude/out/flow.csv", index=False)
pd.set_option("display.width", 200, "display.max_colwidth", 110)
print(fl.to_string(index=False))
print("\nFINAL N =", len(d), "| NAFLD (HSI>36) n =", int(d.nafld.sum()), f"({d.nafld.mean()*100:.1f}% unweighted)")
print(d.groupby("year").nafld.agg(["size", "sum", "mean"]).round(3))
json.dump(dict(final_n=len(d), nafld=int(d.nafld.sum()), lines=n_lines_total, unparsable_ids=len(bad_ids)), open("/home/claude/out/flow.json","w"))
