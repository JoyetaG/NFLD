import pandas as pd, numpy as np, statsmodels.api as sm, json, warnings
warnings.filterwarnings("ignore")
import lightgbm as lgb
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score
u = pd.read_pickle("/home/claude/uniq.pkl"); d = pd.read_pickle("/home/claude/out/analytic.pkl").reset_index(drop=True)
d = d.merge(u[['ID','HE_ht','HE_wt']], on="ID", how="left", suffixes=("","_u")); d["w"]=d.wt_tot/d.wt_tot.mean()
bmr = np.where(d.sex==1, 10*d.HE_wt+6.25*d.HE_ht-5*d.age+5, 10*d.HE_wt+6.25*d.HE_ht-5*d.age-161); d["ei_bmr"]=d.N_EN/bmr
ok = d[(d.ei_bmr>=0.9)&(d.ei_bmr<=2.5)].copy()
print(f"All: n={len(d):,}; plausible reporters n={len(ok):,} ({len(ok)/len(d)*100:.1f}%); under-reporters (EI/BMR<0.9): {(d.ei_bmr<0.9).mean()*100:.1f}% (NAFLD {(d.ei_bmr<0.9)[d.nafld==1].mean()*100:.1f}% vs non {(d.ei_bmr<0.9)[d.nafld==0].mean()*100:.1f}%); over (>2.5): {(d.ei_bmr>2.5).mean()*100:.1f}%")
inc = [("Dietary fibre","N_FIBER",5,"g/day"),("Sodium","N_NA",1000,"mg/day"),("Potassium","N_K",500,"mg/day"),("Vitamin C","N_VITC",50,"mg/day"),("Calcium","N_CA",100,"mg/day"),("Total fat","N_FAT",10,"g/day"),("Carbohydrate","N_CHO",50,"g/day"),("Protein","N_PROT",10,"g/day"),("Water","N_WATER",250,"mL/day"),("Energy","N_EN",500,"kcal/day")]
def fit(data, c, sc):
    covs=["age","female","smoker","active"]+(["N_EN"] if c!="N_EN" else [])
    X = sm.add_constant(pd.concat([(data[c]/sc).rename("x"), data[covs].astype(float), pd.get_dummies(data[["year","edu","incm"]].astype(int).astype(str), drop_first=True).astype(float)],axis=1))
    m = sm.GLM(data.nafld, X, family=sm.families.Binomial(), freq_weights=data.w).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(data.grp)[0]})
    lo,hi=np.exp(m.conf_int().loc["x"]); return f"{np.exp(m.params['x']):.2f} ({lo:.2f}–{hi:.2f})", m.pvalues["x"]
rows=[]
for lab,c,sc,unit in inc:
    a,pa = fit(d,c,sc); b,pb = fit(ok,c,sc); rows.append([lab, f"per {sc:g} {unit}", a, b]); print(f"{lab:14s} all {a:18s} plausible {b}  (p {pa:.3f} -> {pb:.3f})")
json.dump(dict(rows=rows, n_all=len(d), n_ok=len(ok), under_all=float((d.ei_bmr<0.9).mean()*100), under_naf=float((d.ei_bmr<0.9)[d.nafld==1].mean()*100), under_non=float((d.ei_bmr<0.9)[d.nafld==0].mean()*100)), open("/home/claude/out/plausible.json","w"))
# does cleaning improve prediction? Set D (diet+age/lifestyle) vs E among plausible reporters
diet=['N_EN','N_WATER','N_PROT','N_FAT','N_CHO','N_FIBER','N_ASH','N_CA','N_PHOS','N_FE','N_NA','N_K','N_VA','N_CAROT','N_RETIN','N_B1','N_B2','N_NIAC','N_VITC']
for df in (d, ok): df["yearn"]=df.year-2008
life=['age','smoker','active','edu','incm','yearn']
for nm,data in [("all participants",d),("plausible reporters",ok)]:
    data=data.reset_index(drop=True); y=data.nafld.values; g=pd.factorize(data.grp)[0]; folds=list(GroupKFold(5).split(data,y,g)); res={}
    for lab,fs in [("diet + age/lifestyle",life+diet),("age/lifestyle only",life)]:
        oof=np.zeros(len(data))
        for tr,te in folds:
            m=lgb.LGBMClassifier(n_estimators=300,learning_rate=0.05,num_leaves=15,subsample=0.8,subsample_freq=1,colsample_bytree=0.8,verbose=-1,n_jobs=1,random_state=1).fit(data.loc[tr,fs],y[tr]); oof[te]=m.predict_proba(data.loc[te,fs])[:,1]
        res[lab]=roc_auc_score(y,oof)
    print(f"AUROC {nm}: diet+age/lifestyle {res['diet + age/lifestyle']:.3f} vs age/lifestyle only {res['age/lifestyle only']:.3f}")
