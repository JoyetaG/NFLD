import pandas as pd, numpy as np, statsmodels.api as sm, json, warnings
warnings.filterwarnings("ignore")
u = pd.read_pickle("/home/claude/uniq.pkl"); d = pd.read_pickle("/home/claude/out/analytic.pkl").reset_index(drop=True)
F = ['F_HAMBER','F_PIZZA','F_FRIED','F_SODA']
d = d.merge(u[['ID','HE_vitD','urineNa_excretion']+F], on="ID", how="left", suffixes=("","_u"))
for c in F: d.loc[d[c]>=90, c]=np.nan
d["w"]=d.wt_tot/d.wt_tot.mean(); grp_all = d.grp
z = lambda s: (s-s.mean())/s.std()
d["fat_pct"]=d.N_FAT*9/d.N_EN*100
dd = d.dropna(subset=F).copy()
for c in ["fat_pct"]: dd[c+"_z"]=z(dd[c])
dd["fastfood_z"] = z(z(dd.F_HAMBER)+z(dd.F_PIZZA)+z(dd.F_FRIED)); dd["soda_z"]=z(dd.F_SODA)
dd["inactive"] = (1-dd.active).astype(int)
dd["alt_high"] = (dd.HE_alt > np.where(dd.sex==1,33,25)).astype(int)
dd["vitd_z"] = z(dd.HE_vitD); dd["una_z"] = z(dd.urineNa_excretion)
print(f"n={len(dd):,}; physically inactive (none of vigorous/moderate/walking): {dd.inactive.mean()*100:.1f}% unweighted, weighted {np.average(dd.inactive,weights=dd.w)*100:.1f}%; inactive in NAFLD {dd.inactive[dd.nafld==1].mean()*100:.1f}% vs {dd.inactive[dd.nafld==0].mean()*100:.1f}%")
def fit(data, y, xs, drop_active=False):
    base = ["age","female","smoker"] + ([] if drop_active else ["active"])
    X = sm.add_constant(pd.concat([data[xs].astype(float), data[base].astype(float), pd.get_dummies(data[["year","edu","incm"]].astype(int).astype(str), drop_first=True).astype(float)],axis=1))
    m = sm.GLM(data[y], X, family=sm.families.Binomial(), freq_weights=data.w).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(data.grp)[0]})
    return {x:(float(np.exp(m.params[x])), *[float(v) for v in np.exp(m.conf_int().loc[x])], float(m.pvalues[x])) for x in xs}
out = {}
for y in ["nafld","alt_high"]:
    res = {}
    res["fat"] = fit(dd,y,["fat_pct_z"])["fat_pct_z"]; res["fastfood"]=fit(dd,y,["fastfood_z"])["fastfood_z"]; res["soda"]=fit(dd,y,["soda_z"])["soda_z"]
    res["inactive"] = fit(dd,y,["inactive"],drop_active=True)["inactive"]
    v = dd.dropna(subset=["vitd_z"]); res["vitd"]=fit(v,y,["vitd_z"])["vitd_z"]
    n = dd.dropna(subset=["una_z"]); res["una"]=fit(n,y,["una_z"])["una_z"]
    mut = fit(dd,y,["fat_pct_z","fastfood_z","soda_z","inactive"],drop_active=True); res["mut"]={k.replace("_z",""):v_ for k,v_ in mut.items()}
    out[y]=res
out["n"]={"main":len(dd),"vitd":int(dd.vitd_z.notna().sum()),"una":int(dd.una_z.notna().sum())}
# fast food x inactivity joint
dd["ff_high"] = (dd.fastfood_z > dd.fastfood_z.quantile(2/3)).astype(int)
dd["joint"] = dd.ff_high*2 + dd.inactive   # 0 active/low,1 inactive/low,2 active/high,3 inactive/high
J = pd.get_dummies(dd.joint, prefix="j", drop_first=True).astype(float)
for y in ["nafld"]:
    X = sm.add_constant(pd.concat([J, dd[["age","female","smoker"]].astype(float), pd.get_dummies(dd[["year","edu","incm"]].astype(int).astype(str), drop_first=True).astype(float)],axis=1))
    m = sm.GLM(dd[y], X, family=sm.families.Binomial(), freq_weights=dd.w).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(dd.grp)[0]})
    out["joint"]={c:(float(np.exp(m.params[c])), *[float(v) for v in np.exp(m.conf_int().loc[c])], float(m.pvalues[c])) for c in J.columns}
    dd["ffx"] = dd.ff_high.astype(float)*dd.inactive
    X2 = sm.add_constant(pd.concat([dd[["ff_high","inactive","ffx"]].astype(float), dd[["age","female","smoker"]].astype(float), pd.get_dummies(dd[["year","edu","incm"]].astype(int).astype(str), drop_first=True).astype(float)],axis=1))
    m2 = sm.GLM(dd[y], X2, family=sm.families.Binomial(), freq_weights=dd.w).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(dd.grp)[0]}); out["interaction_p"]=float(m2.pvalues["ffx"])
fmt = lambda t: f"{t[0]:.2f} ({t[1]:.2f}-{t[2]:.2f}); p={t[3]:.3g}"
for y in ["nafld","alt_high"]:
    print("\nOUTCOME", y)
    for k in ["fat","fastfood","soda","inactive","vitd","una"]: print(f"  {k:9s} separate: {fmt(out[y][k])}")
    print("  mutually adjusted:", {k: fmt(v_) for k,v_ in out[y]["mut"].items()})
print("\njoint fast-food(high tertile) x inactivity, NAFLD: (1=inactive/low FF, 2=active/high FF, 3=inactive/high FF vs active/low FF)"); print({k: fmt(v_) for k,v_ in out["joint"].items()}, "interaction p =", round(out["interaction_p"],3))
print(out["n"])
json.dump(out, open("/home/claude/out/extras.json","w"))
dd.to_pickle("/home/claude/out/extras_data.pkl")
