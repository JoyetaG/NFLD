import pandas as pd, numpy as np, statsmodels.api as sm, warnings
warnings.filterwarnings("ignore")
from scipy import stats
u = pd.read_pickle("/home/claude/uniq.pkl"); dd = pd.read_pickle("/home/claude/out/extras_data.pkl").reset_index(drop=True)
dd = dd.merge(u[['ID','HE_ht','HE_wt','N_DUSUAL','N_DIET']], on="ID", how="left", suffixes=("","_u"))
print("=== 1. Special/missing codes in variables used (analytic n=%d)" % len(dd))
for c in ['sm_presnt','pa_high','pa_mid','pa_walk','edu','incm','HE_DMdg','N_DUSUAL','N_DIET']:
    print(f"  {c:9s}", dd[c].astype(str).value_counts().head(8).to_dict())
print("\n=== 2. Extreme values / skew of nutrient exposures")
for c in ['N_FIBER','N_NA','N_K','N_FAT','N_EN']:
    s=dd[c]; print(f"  {c:8s} mean {s.mean():8.1f} SD {s.std():8.1f} median {s.median():8.1f} p99 {s.quantile(.99):8.1f} max {s.max():9.1f} | skew {stats.skew(s):4.1f}")
# ---------- sensitivity helper
g = pd.factorize(dd.grp)[0]
def orx(data, x, y="nafld", drop_active=False):
    covs=["age","female","smoker"]+([] if drop_active else ["active"]); gg=pd.factorize(data.grp)[0]
    X = sm.add_constant(pd.concat([data[[x]].astype(float), data[covs].astype(float), pd.get_dummies(data[["year","edu","incm"]].astype(int).astype(str), drop_first=True).astype(float)],axis=1))
    m = sm.GLM(data[y], X, family=sm.families.Binomial(), freq_weights=data.w).fit(cov_type="cluster", cov_kwds={"groups": gg})
    lo,hi=np.exp(m.conf_int().loc[x]); return f"{np.exp(m.params[x]):.2f} ({lo:.2f}-{hi:.2f})"
z = lambda s:(s-s.mean())/s.std()
dd["fiber_dens"]=dd.N_FIBER/dd.N_EN*1000; dd["na_dens"]=dd.N_NA/dd.N_EN*1000; dd["k_dens"]=dd.N_K/dd.N_EN*1000
def wins(s): return s.clip(s.quantile(.01), s.quantile(.99))
ex = [("Fibre density","fiber_dens"),("Sodium density","na_dens"),("Potassium density","k_dens"),("Fat % energy","fat_pct"),("Soda freq","F_SODA")]
print("\n=== 3. Does outlier handling change the odds ratios? (per SD, NAFLD, weighted, fully adjusted)")
for lab,c in ex:
    d2 = dd.copy(); d2["a"]=z(d2[c]); d2["b"]=z(wins(d2[c])); d2["c"]=z(np.log1p(d2[c]))
    print(f"  {lab:18s} raw {orx(d2,'a'):18s} winsorised 1-99% {orx(d2,'b'):18s} log {orx(d2,'c')}")
# ---------- reporting plausibility (Mifflin-St Jeor)
bmr = np.where(dd.sex==1, 10*dd.HE_wt+6.25*dd.HE_ht-5*dd.age+5, 10*dd.HE_wt+6.25*dd.HE_ht-5*dd.age-161)
dd["ei_bmr"]=dd.N_EN/bmr
print("\n=== 4. Energy-reporting plausibility (EI/BMR)")
print("  median EI/BMR overall %.2f; NAFLD %.2f vs non-NAFLD %.2f" % (dd.ei_bmr.median(), dd.ei_bmr[dd.nafld==1].median(), dd.ei_bmr[dd.nafld==0].median()))
low = dd.ei_bmr<1.0; print("  EI/BMR < 1.0 (likely under-reporting): %.1f%% overall; NAFLD %.1f%% vs non-NAFLD %.1f%%" % (low.mean()*100, low[dd.nafld==1].mean()*100, low[dd.nafld==0].mean()*100))
ok = dd[(dd.ei_bmr>=0.9)&(dd.ei_bmr<=2.5)].copy(); print("  plausible reporters (0.9 <= EI/BMR <= 2.5): n=%d (%.1f%%)" % (len(ok), len(ok)/len(dd)*100))
for lab,c in ex:
    a=dd.copy(); a["x"]=z(a[c]); b=ok.copy(); b["x"]=z(b[c]); print(f"  {lab:18s} all {orx(a,'x'):18s} plausible reporters only {orx(b,'x')}")
# ---------- usual-day recalls
uday = dd[dd.N_DUSUAL.astype(str)=="1"].copy(); print("\n=== 5. Usual-intake-day recalls only: n=%d (%.1f%%)" % (len(uday), len(uday)/len(dd)*100))
for lab,c in ex[:4]:
    a=dd.copy(); a["x"]=z(a[c]); b=uday.copy(); b["x"]=z(b[c]); print(f"  {lab:18s} all {orx(a,'x'):18s} usual day only {orx(b,'x')}")
# ---------- how much of HSI is BMI?
print("\n=== 6. The outcome itself")
print("  Spearman(HSI, BMI) = %.2f ; R2 of HSI explained by BMI alone = %.2f" % (stats.spearmanr(dd.HSI,dd.HE_BMI)[0], np.corrcoef(dd.HSI,dd.HE_BMI)[0,1]**2))
print("  Diet vs BMI (Spearman): " + ", ".join(f"{lab} {stats.spearmanr(dd[c],dd.HE_BMI,nan_policy='omit')[0]:+.2f}" for lab,c in ex))
print("  Diet vs HSI  (Spearman): " + ", ".join(f"{lab} {stats.spearmanr(dd[c],dd.HSI,nan_policy='omit')[0]:+.2f}" for lab,c in ex))
