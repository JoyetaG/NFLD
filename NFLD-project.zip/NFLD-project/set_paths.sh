#!/bin/bash
# Optional: the scripts were run with absolute paths (/home/claude/..., /mnt/user-data/outputs/...).
# This rewrites them to paths relative to the repository root, using ./out for intermediate files and ./figures for figures.
# Review the diff before running; this rewrite has not been executed end to end.
mkdir -p out figures data
sed -i 's#/mnt/user-data/uploads/#data/#g; s#/mnt/user-data/outputs/#figures/#g; s#/home/claude/out/#out/#g; s#/home/claude/#out/#g' code/*.py
echo "Paths rewritten. Place the raw KNHANES file in data/ and run the scripts from the repository root."
